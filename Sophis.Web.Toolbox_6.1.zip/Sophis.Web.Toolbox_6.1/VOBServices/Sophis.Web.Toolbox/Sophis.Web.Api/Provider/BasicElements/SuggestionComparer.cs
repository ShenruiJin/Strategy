﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;


namespace Sophis.Web.Api
{
    public class SuggestionComparer : IEqualityComparer<Suggestion>
    {
        #region IEqualityComparer<Suggestion> Members

        public bool Equals(Suggestion x, Suggestion y)
        {
            if (x.Key == y.Key)
                return true;
            else
                return false;
        }

        public int GetHashCode(Suggestion obj)
        {
            return obj.Key.ToLower().GetHashCode();
        }
        #endregion
    }
}
