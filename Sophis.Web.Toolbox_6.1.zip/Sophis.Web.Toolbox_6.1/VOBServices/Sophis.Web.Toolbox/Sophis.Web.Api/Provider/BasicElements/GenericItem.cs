﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Sophis.Web.Api
{
    public class GenericItem : Suggestion
    {
        
        public string Reference { get; set; }

        public override string ToString()
        {
             return Key;
        }
    }



    
}
