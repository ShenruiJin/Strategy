﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Sophis.Web.Api
{
    public partial class UserPassword : Form
    {
        public UserPassword()
        {
            InitializeComponent();
        }

        public string GetUser()
        {
            return textBox_User.Text;
        }

        public string GetPassword()
        {
            return textBox_Password.Text;
        }
    }
}
