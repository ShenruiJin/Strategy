﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows;


using Sophis.Web.Api;
using sophis.services;


namespace Sophis.Web.Api
{
    /// <summary>
    /// Autcomplete Provider, which Takes any "SQL Provider" derivate as Attibute.
    /// It allow to use the AutoCompleteBoxForSQLProviders
    /// </summary>
    public class SQLAutocompleteProvider : ISuggestionProvider
    {

        public event EventHandler UpdateSelectedSugestion;
        public event EventHandler UpdateSugestionList;

        GenericItem _LastSugestion;
        public GenericItem LastSugestion
        {
            get
            {
                return _LastSugestion;
            }
            set
            {
                _LastSugestion = value;
                if (LastSugestion != null)
                {
                    if (UpdateSelectedSugestion != null)
                        UpdateSelectedSugestion(LastSugestion, null);
                }
            }
        }

        /// <summary>
        /// This is the list
        /// </summary>
        private ObservableCollection<GenericItem> _OriginalList = new ObservableCollection<GenericItem>();
        private SQLProvider _GenericProvider;

        [DefaultValue(true)]
        public bool InitFullList { get; set; }
        public List<long> FilterForPartialList { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="genericProvider">GenericProvider which will provide List</param>
        /// <param name="initFullList">true if we want the full list</param>
        /// <param name="filterForPartialList">if initFullList is false, will filter the returning list on these parameters.</param>
        public SQLAutocompleteProvider(SQLProvider genericProvider, bool initFullList, List<long> filterForPartialList)
        {
            _GenericProvider = genericProvider;
            InitFullList = initFullList;
            FilterForPartialList = filterForPartialList;
            _GenericProvider.PropertyChanged += new PropertyChangedEventHandler(_GenericProvider_PropertyChanged);

            //if We want the Full List, Or if The Filter is null , We load the Full list
            if (InitFullList || (FilterForPartialList == null))
                _GenericProvider.LoadList(true, null);
            else
                _GenericProvider.LoadList(InitFullList, FilterForPartialList);
        }
        #region Set OriginalList
        public void ChangeList(bool initFullList, List<long> ids)
        {
            InitFullList = initFullList;
            FilterForPartialList = ids;

            //if We want the Full List, Or if The Filter is null, We load the Full list
            if (InitFullList || (FilterForPartialList == null))
                _GenericProvider.LoadList(true, null);
            else
                _GenericProvider.LoadList(InitFullList, FilterForPartialList);
        }

        
        void _GenericProvider_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (_GenericProvider != null)
            {
                lock (_OriginalList)
                {
                    //if We want the Full List, The Provider Is In FullList Mode
                    if (_GenericProvider.InitFullList)
                        _OriginalList = _GenericProvider.FullItemlist;
                    else
                        _OriginalList = _GenericProvider.PartialItemlist;
                }
                if (UpdateSugestionList != null)
                    UpdateSugestionList(null, null);
            }
        }
        #endregion Set OriginalList

        #region ISuggestionProvider Members
        /// <summary>
        /// ISuggestionProvider method
        /// Will fill the suggestionlist to present to te user, depending on what is typed in the autocopleteBox
        /// </summary>
        /// <param name="suggestionList"></param>
        /// <param name="prefix"></param>
        /// <param name="maxCount"></param>
        public void LookupPrefix(SuggestionCollection suggestionList, string prefix, int maxCount)
        {
            if (suggestionList == null)
                return;

            suggestionList.Clear();
            int l = prefix.Length;
            foreach (Suggestion sug in _OriginalList)
            {
                string name="";

                name = sug.DisplayName;
                if (name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || prefix.Length == 0)
                {
                    sug.PrefixLength = l;
                    suggestionList.Add(sug);
                }
            }
            if (suggestionList.Count == 1)
                LastSugestion = suggestionList[0] as GenericItem;
        }
        #endregion
    }
}
