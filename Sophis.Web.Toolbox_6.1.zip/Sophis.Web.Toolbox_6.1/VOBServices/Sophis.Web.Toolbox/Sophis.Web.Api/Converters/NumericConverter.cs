﻿using System;
using System.Windows;
using System.Net;
using System.Windows.Markup;
using System.Windows.Data;
using System.Globalization;
using System.ComponentModel;

using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Windows.Controls;


namespace Sophis.Web.Api
{

    #region Converters
    /// <summary>
    /// Convert string to numeric Values
    /// </summary>
    public class NumericConverter : IValueConverter
    {
        public string FORMAT { get; set; }
        public object Convert(object value,
                           Type targetType,
                           object parameter,
                           CultureInfo culture)
        {
            double mydoubleValue = (double)value;
            if (FORMAT.ToUpper().Contains("P"))
                mydoubleValue = mydoubleValue / 100;

            return (mydoubleValue.ToString(FORMAT)); //{0:d2} // "N"
        }

        public object ConvertBack(object value,
                                  Type targetType,
                                  object parameter,
                                  CultureInfo culture)
        {
            string strValue = value.ToString();
            double mydoubleValue = 0.0;
            if (strValue.EndsWith("%"))
                strValue = strValue.Replace("%", "").Trim();

            if (double.TryParse(strValue, out mydoubleValue))
                return mydoubleValue;
            
            return value;
        }
    }   
    
   //CurrentStockLoan.securityPrincipal.dividendRebate.date

    

   

    #endregion Converters

}

