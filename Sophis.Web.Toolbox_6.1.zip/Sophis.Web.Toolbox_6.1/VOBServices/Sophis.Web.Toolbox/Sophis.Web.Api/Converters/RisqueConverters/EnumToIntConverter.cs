﻿using System;
using System.Collections.Generic;
using System.Windows.Data;
using System.Globalization;
using System.Text;

namespace Sophis.Windows.Converters
{
    public class EnumToIntConverter : IValueConverter
    {
        public Type EnumType { get; set; }

        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (null == EnumType || null == value)
                return 0;

            if (EnumType == value.GetType() || value is int)
                return (int)value;

            return 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (null == EnumType || null == value)
                return value;

            return Enum.Parse(EnumType, value.ToString(),true);
        }

        #endregion
    }
}
