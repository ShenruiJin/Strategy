
using System;
using System.Collections.ObjectModel;

namespace Sophis.Web.Api
{
    /// <summary>
    /// ReadOnlySuggestionCollection is a ReadOnlyObservableCollection
    /// of Suggestion objects.
    /// </summary>
    public class ReadOnlySuggestionCollection : ReadOnlyObservableCollection<Suggestion>
    {
        /// <summary>
        /// Initializes a new instance of the ReadOnlySuggestionCollection class that serves
        /// as a wrapper around the specified SuggestionCollection.
        /// </summary>
        /// <param name="suggestionCollection">The SuggestionCollection with which to create this instance
        /// of the ReadOnlySuggestionCollection class</param>
        public ReadOnlySuggestionCollection(SuggestionCollection suggestionCollection)
            : base(suggestionCollection)
        {

        }
    }
}

