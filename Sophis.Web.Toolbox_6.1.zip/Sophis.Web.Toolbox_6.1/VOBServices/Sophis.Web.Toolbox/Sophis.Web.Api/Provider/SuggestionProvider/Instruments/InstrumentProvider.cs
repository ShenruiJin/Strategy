using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Collections.ObjectModel;
using System.Collections;
using sophis.services;


namespace Sophis.Web.Api
{
    public class InstrumentProviderInfo
    {
        public SuggestionCollection SuggestionList;
        public string Prefix;
    }

    public class InstrumentProvider : ISuggestionProviderAsynchronous, I_CommunicationResultGetter
    {
        public event EventHandler UpdateSelectedSugestion;
        public event EventHandler<SugestionListEventArgs> UpdateSugestionList;

        Suggestion _LastSugestion;
        public Suggestion LastSugestion
        {
            get
            {
                return _LastSugestion;
            }
            set
            {
                _LastSugestion = value;
                if (LastSugestion != null)
                {
                    if (UpdateSelectedSugestion != null)
                        UpdateSelectedSugestion(LastSugestion, null);
                }
            }
        }
        

        #region ISuggestionProvider Members
        public void LookupPrefix(SuggestionCollection suggestionList, string prefix, int maxCount)
        {
            if (prefix == "")
                return;

            //prefix = prefix.ToUpper();

            List<SoaMethodParameter> myParams = new List<SoaMethodParameter>() { 
                new SoaMethodParameter { name = "Prefix", Value = prefix },
                new SoaMethodParameter { name = "NbMax", Value = maxCount.ToString() }
            };

            CommunicationResultGetterInfos callerInfos = new CommunicationResultGetterInfos
            {
                Caller = this,
                CallerInfos = new InstrumentProviderInfo { SuggestionList = suggestionList, Prefix = prefix }
            };

            CommunicatorFactory.GetI_Communicator().ExecuteMethod("InstrumentList", myParams, callerInfos);
        }

        private void Parse(SuggestionCollection suggestionList, XDocument xdoc, string prefix)
        {
            if (suggestionList == null || xdoc == null)
                return;

            //Will COmpare Sugestion With Their Key.
            SuggestionComparer sugComparer = new SuggestionComparer();

            XNamespace ns = xdoc.Root.Name.Namespace;

            Suggestion oldSelectedItem = null;
            if (suggestionList.Count == 1)
                oldSelectedItem = suggestionList[0];
            suggestionList.Clear();

            foreach (var instrument in xdoc.Root.Elements(ns + "SoaAcInstrument"))
            {
                string reference = instrument.Element(ns + "Reference").Value;
                string sico = (instrument.Element(ns + "Sico")!=null)?instrument.Element(ns + "Sico").Value:"";
                string name = instrument.Element(ns + "Name").Value;
                string type = instrument.Element(ns + "Type").Value;
                if (reference.StartsWith(prefix, StringComparison.CurrentCultureIgnoreCase))
                {
                    Suggestion instruSug = new XSRInstrumentSuggestion(reference, sico, name, type, prefix.Length);
                    if (suggestionList.Contains(instruSug, sugComparer) == false)
                        suggestionList.Add(instruSug);
                }
            }
            //if the new List IS different from the old one.
            if (suggestionList.Count > 1 
                 || ((suggestionList.Count == 1) && (oldSelectedItem == null)) 
                 || ((suggestionList.Count == 1) &&(suggestionList[0].Key != oldSelectedItem.Key))
                )
            {
                LastSugestion = suggestionList[0];
                //Warn the Control that the List is updated
                if (UpdateSugestionList != null)
                    UpdateSugestionList(this, new SugestionListEventArgs { Suggestions = suggestionList });
            }
        }

        #endregion

        #region I_CommunicationResultGetter Members

        public void MethodHasCompleted(string methodName, XDocument result, object info)
        {
            InstrumentProviderInfo providerInfo = (info as CommunicationResultGetterInfos).CallerInfos as InstrumentProviderInfo;
            SuggestionCollection suggestionList = providerInfo.SuggestionList;
            Parse(suggestionList, result, providerInfo.Prefix);
        }
        public void MethodFailed(string methodName, XDocument result, object info)
        {
        }

        #endregion
    }
}



