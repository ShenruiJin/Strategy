using System;
using System.Collections.ObjectModel;

namespace Sophis.Web.Api
{
    /// <summary>
    /// SuggestionCollection is an ObservableCollection of Suggestion objects.
    /// </summary>
    public class SuggestionCollection : ObservableCollection<Suggestion>
    {
        

        /// <summary>
        /// Return true if the collection already contains a sugestion with the same key.
        /// </summary>
        /// <param name="key">string : Suggestion Key</param>
        /// <returns></returns>
        public bool Contains(string key)
        {
            foreach (Suggestion s in this.Items)
            {
                if (s.Key.Equals(key, StringComparison.CurrentCultureIgnoreCase))
                    return true;
            }
            return false;
        }
    }
}
