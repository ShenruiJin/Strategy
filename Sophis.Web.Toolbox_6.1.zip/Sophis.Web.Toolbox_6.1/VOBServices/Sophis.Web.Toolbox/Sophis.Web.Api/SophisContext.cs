﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sophis.Web.Base;

namespace Sophis.Web.Api
{
    public class SophisContext : Context
    {
        public SophisContext(Configuration configuration)
            : base(configuration)
        {
            if (configuration is SophisConfiguration)
                SophisConfiguration = (SophisConfiguration)configuration;
            else
                SophisConfiguration = new SophisConfiguration(configuration);
        }

        public SophisConfiguration SophisConfiguration { get; private set; }

        public SophisCommunicationManager CommunicationManager
        {
            get
            {
                if (_CommunicationManager == null)
                    _CommunicationManager = new SophisCommunicationManager(SophisConfiguration);
                return _CommunicationManager;
            }
        }



        private SophisCommunicationManager _CommunicationManager;
    }
}
