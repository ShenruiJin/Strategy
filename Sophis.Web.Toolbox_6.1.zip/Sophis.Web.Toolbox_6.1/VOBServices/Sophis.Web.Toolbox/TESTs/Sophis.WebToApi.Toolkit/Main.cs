﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Sophis.Web.Api.TestingAppli.SL;

namespace Sophis.WebToApi.Toolkit
{
    public class Main : sophis.IMain
    {
        #region IMain Members

        public void Close()
        {
            throw new NotImplementedException();
        }

        public void EntryPoint()
        {
            sophis.scenario.CSMScenario.Register("CSharpScenario", new CSharpScenario());
            
        }

        #endregion
    }

    public class CSharpScenario : sophis.scenario.CSMScenario
    {
        public override void Run()
        {
            Sophis.Web.Api.TestingAppli.SL.MainPage MainPage = new Sophis.Web.Api.TestingAppli.SL.MainPage();
            Sophis.Windows.Integration.WPFAdapter.Instance.OpenWindow(MainPage, "Hello Test ! ");
        }

        public override bool AlwaysEnabled()
        {
            return true;
        }
    }

}
