using System;
using System.Windows;
using System.Windows.Data;
using System.Globalization;

namespace Sophis.Windows.Converters
{
    /** Converter that transform a bool into a Visibility value.
        @version 6.0
        @DLL SphGuiCommon
    */
    //[ValueConversion(typeof(bool), typeof(Visibility))]
    public class VisibilityConverter : IValueConverter
    {
        private bool fIsCollapsed = true;
        private bool fReverse = false;

        public bool IsCollapsed
        {
            get { return fIsCollapsed; }
            set { fIsCollapsed = value; }
        }

        public bool Reverse
        {
            get { return fReverse; }
            set { fReverse = value; }
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (null != value)
            {
                bool isVisible = (bool)value;
                if (Reverse)
                    isVisible = !isVisible;
                if (isVisible)
                    return Visibility.Visible;
            }
            //if (IsCollapsed)
                return Visibility.Collapsed;
            //else
            //    return Visibility.Hidden;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    };
}
