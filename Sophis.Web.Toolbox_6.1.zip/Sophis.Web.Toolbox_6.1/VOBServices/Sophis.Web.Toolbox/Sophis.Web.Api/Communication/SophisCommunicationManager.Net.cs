﻿using System;
using System.Net;
using System.ServiceModel;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Xml.Serialization;

using sophis;
using sophis.services;
using Sophis.Web.Base;
using System.Timers;


namespace Sophis.Web.Api
{

    public class NS
    {
        static public XNamespace fpml = "http://www.fpml.org/2005/FpML-4-2";
        static public XNamespace xsi = "http://www.w3.org/2001/XMLSchema-instance";
        static public XNamespace nsDataExchange = "http://sophis.net/sophis/gxml/dataExchange";
        static public XNamespace nsCommon = "http://www.sophis.net/common";
        static public XNamespace nsCommon2 = "http://sophis.net/sophis/common";
        static public XNamespace nsR = "http://www.sophis.net/reporting";
        static public XNamespace nsNetR = "http://www.sophis.net/DotNetReporting";
        static public XNamespace nsInstrument = "http://www.sophis.net/Instrument";
        static public XNamespace nsFund = "http://www.sophis.net/fund";
        static public XNamespace nsValuation = "http://www.sophis.net/valuation";
        static public XNamespace nsDividend = "http://www.sophis.net/dividend";
        static public XNamespace nsVolatility = "http://www.sophis.net/volatility";
        static public XNamespace nsTrade = "http://www.sophis.net/trade";
        static public XNamespace nsReporting = "http://www.sophis.net/reporting";
        static public XNamespace nsFolio = "http://www.sophis.net/folio";
    }

    public class SophisCommunicationManager: I_CommunicationManager
    {
       #region Data
        #region Data - 3 WebServices,
        /// <summary>
        /// Sophis DataExchange WebService 
        /// Allox to import and export object through their Xml description
        /// </summary>
        public  DataExchangeService ServiceDataExchange
        {
            get { return (_ServiceDataExchange as DataExchangeService); }
        }
        DataExchangeServiceClient _ServiceDataExchange = null;
        
        /// <summary>
        /// Sophis Valuation WebService, 
        /// Allow to Compute Folio, retreive Extracations etc...
        /// </summary>
        public ValuationService ServiceValuation
        {
            get { return (_ServiceValuation as sophis.services.ValuationService); }
        }
        ValuationServiceClient _ServiceValuation = null;

        /// <summary>
        /// Sophis SoaMethodsDesigner WebService
        /// Allow To process 
        /// </summary>
        public SoaMethodDesignerService ServiceSoaDesigner
        {
            get { return (_ServiceSoaDesigner as SoaMethodDesignerService); }
        }
        SoaMethodDesignerServiceClient _ServiceSoaDesigner = null;
        #endregion Data - 3 WebServices

        #region Data-Serializer
       


        private static XmlSerializer _XmlSophisSerializer = null;

        XmlSerializer SophisSerializer
        {
            get
            {
                if (_XmlSophisSerializer == null)
                {
                    ///Serialize
                    XmlRootAttribute xmlRoot = new XmlRootAttribute();
                    xmlRoot.ElementName = "message";
                    xmlRoot.Namespace = "http://sophis.net/sophis/gxml/dataExchange";
                    _XmlSophisSerializer = new XmlSerializer(typeof(Message), xmlRoot);
                }
                return _XmlSophisSerializer;
            }
        }

        private static XmlSerializer _XmlValuationSerializer = null;

        XmlSerializer ValuationSerializer
        {
            get
            {
                if (_XmlValuationSerializer == null)
                {
                    ///Serialize
                    XmlRootAttribute xmlRoot = new XmlRootAttribute();
                    xmlRoot.ElementName = "message";
                    xmlRoot.Namespace = "http://sophis.net/sophis/gxml/dataExchange";
                    _XmlValuationSerializer = new XmlSerializer(typeof(Message), xmlRoot);
                }
                return _XmlValuationSerializer;
            }
        }

        #endregion Data-Serializer

        #region Data - Login
        /// <summary>
        /// Event Thrown by CommunicationManager, Once it is Well logged to each instanciated Webservice
        /// </summary>
        public event EventHandler CommunicationManagerLogged;
        public event EventHandler CommunicationManagerUnLogged;

        /// <summary>
        /// Check if each instanciate WebService is well logged
        /// </summary>
        public bool IsLogged
        {
            get
            {
                bool isLogged = false;
                //at least  1 Service is Needed 
                if (_ServiceDataExchange != null || _ServiceValuation != null || _ServiceSoaDesigner != null)
                {
                    isLogged = true;

                    if (_ServiceDataExchange != null && _LoggedInDataExchange == false)
                        isLogged = false;
                    if (_ServiceValuation != null && _LoggedInValuation == false)
                        isLogged = false;
                    if (_ServiceSoaDesigner != null && _LoggedInSoaMd == false)
                        isLogged = false;
                }

                return isLogged;
            }
        }

        private bool _LoggedInDataExchange = false;
        private bool _LoggedInValuation = false;
        private bool _LoggedInSoaMd = false;
        #endregion region Data - Login

        #region Data-Configuration
            SophisConfiguration _Configuration;
            public Sophis.Web.Base.Configuration Configuration
            {
                get
                {
                    return _Configuration;
                }
            }
        #endregion Data-Configuration
         
       #endregion Data


            #region Constructor & Init
            /// <summary>
        /// 
        /// </summary>
        public SophisCommunicationManager()
        {
            _Configuration = new SophisConfiguration();

            InitConnection();
        }

        /// <summary>
        /// In this CAse, SophisConfiguration can be SophisConfigurationWithLogs
        /// </summary>
        /// <param name="configuration"></param>
        public SophisCommunicationManager(SophisConfiguration configuration)
        {
            _Configuration = configuration;
            InitConnection();
        }

        public bool Disconnect()
        {
            try
            {
                //DatExchange
                if (_ServiceDataExchange != null)
                    _ServiceDataExchange.logout(new Logout());

                //Valuation
                if (_ServiceValuation != null)
                    _ServiceValuation.logout(new Logout1());

                //SoaMethod
                if (_ServiceSoaDesigner != null)
                    _ServiceSoaDesigner.logout(new Logout2());

                if (CommunicationManagerUnLogged != null)
                    CommunicationManagerUnLogged(this, new EventArgs());

                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        void InitConnection()
        {
            // disable certificate checks
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(
                delegate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
                {
                    return true;
                });

            if (_Configuration.SoaPackUserName == string.Empty)
            {
                UserPassword form = new UserPassword();
                if (form.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    _Configuration.SoaPackUserName = form.GetUser();
                    _Configuration.SoaPackPassword = form.GetPassword();
                }
            }

            string user = _Configuration.SoaPackUserName;
            string password = _Configuration.SoaPackPassword;

            //Build the Service DataExchange
            if (_Configuration.IsDataExchangeServiceAvailable)
            {
                System.ServiceModel.EndpointAddress adressDataExchange = new System.ServiceModel.EndpointAddress(_Configuration.DataExchangeAdress);
                //Init the Web Service
                BasicHttpBinding binding = GetBasicBinding (adressDataExchange);
                binding.AllowCookies = true;
                _ServiceDataExchange = new DataExchangeServiceClient(binding, adressDataExchange);

                //Security & Login
                _ServiceDataExchange.ChannelFactory.Credentials.UserName.UserName = user;
                _ServiceDataExchange.ChannelFactory.Credentials.UserName.Password = password;
            }
            //Build the Service Valuation
            if (_Configuration.IsValuationServiceAvailable)
            {
                System.ServiceModel.EndpointAddress adressValuation = new System.ServiceModel.EndpointAddress(_Configuration.ValuationAdress);
                //Init the Web Service
                BasicHttpBinding binding = GetBasicBinding(adressValuation);
                binding.AllowCookies = true;
                _ServiceValuation = new ValuationServiceClient(binding, adressValuation);
                //Security & Login
                _ServiceValuation.ChannelFactory.Credentials.UserName.UserName = user;
                _ServiceValuation.ChannelFactory.Credentials.UserName.Password = password;
            }

            //Build the Service SoaMethods Designer
            if (_Configuration.IsSoaMdServiceAvailable)
            {
                System.ServiceModel.EndpointAddress adressSoaMd = new System.ServiceModel.EndpointAddress(_Configuration.SoaMethodDesignerAdress);
                //Init the Web Service
                BasicHttpBinding binding = GetBasicBinding(adressSoaMd);
                binding.AllowCookies = true;
                _ServiceSoaDesigner = new SoaMethodDesignerServiceClient(binding, adressSoaMd);
                //Security & Login
                _ServiceSoaDesigner.ChannelFactory.Credentials.UserName.UserName = user;
                _ServiceSoaDesigner.ChannelFactory.Credentials.UserName.Password = password;  
            }

            //Do All Login Stuff to Connect Every Thing
            this.Connect();
        }
        private BasicHttpBinding GetBasicBinding(System.ServiceModel.EndpointAddress adress)
        {
            BasicHttpBinding basicBinding = new BasicHttpBinding();
            basicBinding.MaxBufferSize = 65536000;
            basicBinding.MaxReceivedMessageSize = 65536000;
            basicBinding.MaxBufferPoolSize = 655360000;
            //This Setting need "System.Runtime.Serialization.dll"
            basicBinding.ReaderQuotas.MaxArrayLength = 65536000;
            basicBinding.ReaderQuotas.MaxNameTableCharCount= 65536000;
            basicBinding.ReaderQuotas.MaxStringContentLength = 655360000;

            basicBinding.SendTimeout = new TimeSpan(0, 0, 10, 0);
            basicBinding.ReceiveTimeout = new TimeSpan(0, 0, 10, 0);
            if (adress.Uri.AbsoluteUri.Contains("https"))
                basicBinding.Security.Mode = BasicHttpSecurityMode.Transport;//TransportWithMessageCredential;
            else
                basicBinding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;

            basicBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            basicBinding.Security.Transport.ProxyCredentialType = HttpProxyCredentialType.Basic;
            basicBinding.Security.Message.ClientCredentialType = BasicHttpMessageCredentialType.UserName;

            return basicBinding;
        }

        private void Connect()
        {
            if (_Configuration.IsDataExchangeServiceAvailable)
            {
                Login l = new Login();
                LoginResponse resp = _ServiceDataExchange.login(l);
                if (resp.error.code != ErrorCode.SUCCESS)
                    throw (new Exception("DataExchangeServiceClient created, but Unable to Log to DataExchange"));
                else
                    _LoggedInDataExchange = true;
            }

            if (_Configuration.IsValuationServiceAvailable)
            {
                Login1 l = new Login1();
                LoginResponse1 resp = _ServiceValuation.login(l);
                if (resp.error.code != ErrorCode1.SUCCESS)
                    throw (new Exception("ValuationServiceClient created, but Unable to Log to Valuation"));
                else
                    _LoggedInValuation = true;
            }

            if (_Configuration.IsSoaMdServiceAvailable)
            {
                Login2 l = new Login2();
                LoginResponse2 resp = _ServiceSoaDesigner.login(l);
                if (resp.error.code != ErrorCode2.SUCCESS)
                    throw (new Exception("SoaMethodDesignerServiceClient created, but Unable to Log to SoaMethodsDesigner"));
                else
                    _LoggedInSoaMd = true;
            }


            if (IsLogged)
            {
                if (CommunicationManagerLogged != null)
                    CommunicationManagerLogged(this, new EventArgs());
            }

            //Launch the reconnection Timer
            this.InitTimer();
        }
         #endregion Constructor & Init

        #region Auto Refresh & Disconnect Timer
        private System.Timers.Timer _Timer;
        private void InitTimer()
        {
            if (_Timer == null)
            {

                _Timer = new System.Timers.Timer(_Configuration.ReconnectionDelay.TotalMilliseconds);
                _Timer.Elapsed += new ElapsedEventHandler(Timer_Elapsed);
                _Timer.AutoReset = true;
                _Timer.Start();
            }
        }
        private void StopTimer()
        {
            if (_Timer != null)
            {
                _Timer.Stop();
                _Timer = null;
            }
        }
        void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            StopTimer();
            if (Disconnect())
            {
                this.Connect();
            }
        }
        #endregion

        #region Methods -SOA MD- Specific
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="paramList"></param>
        /// <param name="callerInfos"></param>
        public void ExecuteMethod(string methodName, List<SoaMethodParameter> paramList, CommunicationResultGetterInfos callerInfos)
        {
            callerInfos.MethodName = methodName;

            ExecuteSoaMethods exec = new ExecuteSoaMethods();
            exec.soaMethodsRequest = new SoaMethodsRequest();
            exec.soaMethodsRequest.soaMethod = new SoaMethod[1];
            exec.soaMethodsRequest.soaMethod[0] = new SoaMethod();
            exec.soaMethodsRequest.soaMethod[0].name = methodName;
            exec.soaMethodsRequest.soaMethod[0].param = new sophis.services.SoaMethodParameter[paramList.Count];
            exec.soaMethodsRequest.version = DocumentVersion.Item42;
            for (int indexparam = 0; indexparam < paramList.Count; indexparam++)
            {
                exec.soaMethodsRequest.soaMethod[0].param[indexparam] = new sophis.services.SoaMethodParameter
                          {
                              name = paramList[indexparam].name,
                              Value = paramList[indexparam].Value

                          };
            }
            //DirectCall is Commented, caus Not fast Enough (So, Self Serialization)
            //_ServiceSoaDesigner.executeSoaMethodsAsync(exec, callerInfos);

            XDocument resultXdoc = null;
            ProcessRaw processRaw = new ProcessRaw();
            processRaw.message = serializeAsText(exec.soaMethodsRequest);

            bool hasFailed = false;

            //if (resp.response != null)
            //{
            //    XDocument resultXdocFull = XDocument.Parse(resp.response);
            //    XNode node = resultXdocFull.Root.Element(NS.nsR + "soaMethodResult").FirstNode;
            //    resultXdoc = new XDocument(node);
            //}
            ProcessRawResponse resp = _ServiceSoaDesigner.processRaw(processRaw);
            if (resp.response != null)
            {
                XNode node = new XElement("Unable_to_Retreive_Result", resp.response);
                XDocument resultXdocFull = null;
                try
                {
                    resultXdocFull = XDocument.Parse(resp.response);
                    XNamespace ns = resultXdocFull.Root.Name.Namespace;
                }
                catch (Exception exception)
                {
                    Debug.WriteLine("Error= " + exception.ToString());
                    if (methodName != "Log")
                        Logger.Log("SophisCommunicationManager", "_ServiceSoaDesigner_processRawCompleted", "error", "UnableTo Parse Response : " + "resp.response; Exception = " + exception.ToString());
                }

                if (resultXdocFull != null && resultXdocFull.Root.Element(NS.nsR + "soaMethodResult") != null)
                {
                    node = resultXdocFull.Root.Element(NS.nsR + "soaMethodResult").FirstNode;
                }
                else if (resultXdocFull != null && resultXdocFull.Root.Element(NS.nsDataExchange + "elementRejected") != null)
                {
                    node = resultXdocFull.Root.Element(NS.nsDataExchange + "elementRejected");
                    hasFailed = true;
                    if (methodName != "Log")
                    {
                        string msg = ExtractRejectionMessage(node as XElement);
                        //Logger.Log("SophisCommunicationManager", "_ServiceSoaDesigner_processRawCompleted", "warning", "Method failed : " + msg);
                    }
                }
                resultXdoc = new XDocument(node);
            }

            if (callerInfos != null && callerInfos.Caller != null)
            {
                if (hasFailed == false)
                    callerInfos.Caller.MethodHasCompleted(callerInfos.MethodName, resultXdoc, callerInfos);
                else
                    callerInfos.Caller.MethodFailed(callerInfos.MethodName, resultXdoc, callerInfos);
            }
        }

        /// <summary>
        /// Synchronous Call
        /// Not Compatible With SILVERLIGHT ( Only Asynchronous Call).
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="paramList"></param>
        public XDocument ExecuteMethod(string methodName, List<SoaMethodParameter> paramList)
        {
            ExecuteSoaMethods exec = new ExecuteSoaMethods();
            exec.soaMethodsRequest = new SoaMethodsRequest();
            exec.soaMethodsRequest.soaMethod = new SoaMethod[1];
            exec.soaMethodsRequest.soaMethod[0] = new SoaMethod();
            exec.soaMethodsRequest.soaMethod[0].name = methodName;
            exec.soaMethodsRequest.soaMethod[0].param = new sophis.services.SoaMethodParameter[paramList.Count];
            exec.soaMethodsRequest.version = DocumentVersion.Item42;
            for (int indexparam = 0; indexparam < paramList.Count; indexparam++)
            {
                exec.soaMethodsRequest.soaMethod[0].param[indexparam] = new sophis.services.SoaMethodParameter
                {
                    name = paramList[indexparam].name,
                    Value = paramList[indexparam].Value

                };
            }

            XDocument resultXdoc = null;
            ProcessRaw processRaw = new ProcessRaw();
            processRaw.message = serializeAsText(exec.soaMethodsRequest);

            ProcessRawResponse resp = _ServiceSoaDesigner.processRaw(processRaw);
            if (resp.response != null)
            {
                XDocument resultXdocFull = XDocument.Parse(resp.response); 
                XNode node = null;
                //XNode node = resultXdocFull.Root.Element(NS.nsR + "soaMethodResult").FirstNode;
                //resultXdoc = new XDocument(node);
                if (resultXdocFull != null && resultXdocFull.Root.Element(NS.nsR + "soaMethodResult") != null)
                {
                    node = resultXdocFull.Root.Element(NS.nsR + "soaMethodResult").FirstNode;
                }
                else if (resultXdocFull != null && resultXdocFull.Root.Element(NS.nsDataExchange + "elementRejected") != null)
                {
                    node = resultXdocFull.Root.Element(NS.nsDataExchange + "elementRejected");
                    //hasFailed = true;
                    if (methodName != "Log")
                    {
                        string msg = ExtractRejectionMessage(node as XElement);
                        //Logger.Log("SophisCommunicationManager", "_ServiceSoaDesigner_processRawCompleted", "warning", "Method failed : " + msg);
                    }
                }
                resultXdoc = new XDocument(node);
            }
            return resultXdoc;
        }

        /// <summary>
        /// Serialize SoaMethodsDesigner SoaMethodsRequest as text
        /// using SoaDesignerSerializer
        /// </summary>
        /// <param name="req">SoaMethodsRequest</param>
        /// <returns> string</returns>
        public string serializeAsText(SoaMethodsRequest req)
        {
            XDocument doc = new XDocument();
            using (var writer = doc.CreateWriter())
            {
                SophisSerializer.Serialize(writer, req);
            }
            return doc.ToString();
        }
        #endregion Methods -SOA- Specific

        #region Methods -DataExchange- Specific
        /// <summary>
        /// Decrypt a rejectedMessage
        /// </summary>
        /// <param name="rejected">DataExchange Rejected Message</param>
        /// <returns>Reason of the rejection.</returns>
        public string ExtractRejectionMessage(MessageRejected rejected)
        {
            StringBuilder sb = new StringBuilder();
            if (rejected != null)
            {
                string sep = " Reason: ";
                foreach (Reason reason in rejected.reason)
                {
                    sb.Append(sep);
                    sb.Append(reason.description);
                    sep = ", ";
                }
            }
            return sb.ToString();
        }

        public string ExtractRejectionMessage(XElement xElementRejected)
        {
            if (xElementRejected == null)
                return "RejectionMessage is null";

            StringBuilder sb = new StringBuilder();
            if (xElementRejected != null)
            {
                sb.Append(" RejectionMessage: ");
                sb.Append(" ReasonCode = ");
                sb.Append(xElementRejected.Element(NS.nsDataExchange + "reason").Element(NS.fpml + "reasonCode").Value);
                sb.Append(" ; Description = ");
                sb.Append(xElementRejected.Element(NS.nsDataExchange + "reason").Element(NS.fpml + "description").Value);
                sb.Append(" ; DetailedException = ");
                sb.Append(xElementRejected.Element(NS.nsDataExchange + "details").Element(NS.nsDataExchange + "exception").Value);
            }
            return sb.ToString();
        }


        /// <summary>
        /// Serialize SoaMethodsDesigner SoaMethodsRequest as text
        /// using SoaDesignerSerializer
        /// </summary>
        /// <param name="req">SoaMethodsRequest</param>
        /// <returns> string</returns>
        public string serializeAsText(Message req)
        {
            XDocument doc = new XDocument();
            using (var writer = doc.CreateWriter())
            {
                SophisSerializer.Serialize(writer, req);
            }
            return doc.ToString();
        }



        public XDocument Import(ImportMessage import)
        {
            XDocument resultXdoc = null;
            ImportEntities entities = new ImportEntities();
            entities.import = import;
            ProcessEntitiesRaw entityRaw = new ProcessEntitiesRaw();
            entityRaw.message = serializeAsText(import);
            processEntitiesRawRequest req = new processEntitiesRawRequest();
            req.processEntitiesRaw = entityRaw;
            ProcessEntitiesRawResponse resp = ServiceDataExchange.processEntitiesRaw(req).processEntitiesRawResponse;
            if (resp.response != null)
            {
                resultXdoc = XDocument.Parse(resp.response);
            }
            return resultXdoc;
        }

        public XDocument Import(string importString)
        {
            XDocument resultXdoc = null;
            ProcessEntitiesRaw entityRaw = new ProcessEntitiesRaw();
            entityRaw.message = importString;
            processEntitiesRawRequest req = new processEntitiesRawRequest();
            req.processEntitiesRaw = entityRaw;
            ProcessEntitiesRawResponse resp = ServiceDataExchange.processEntitiesRaw(req).processEntitiesRawResponse;
            if (resp.response != null)
            {
                resultXdoc = XDocument.Parse(resp.response);
            }
            return resultXdoc;
        }

        public XDocument Export(ExportMessage export)
        {
            XDocument resultXdoc = null;
            ExportEntities entities = new ExportEntities();
            entities.export = export;
            ProcessEntitiesRaw entityRaw = new ProcessEntitiesRaw();
            entityRaw.message = serializeAsText(export);
            processEntitiesRawRequest req = new processEntitiesRawRequest();
            req.processEntitiesRaw = entityRaw;
            ProcessEntitiesRawResponse resp = ServiceDataExchange.processEntitiesRaw(req).processEntitiesRawResponse;
            if (resp.response != null)
            {
                resultXdoc = XDocument.Parse(resp.response);
            }
            return resultXdoc;
        }

        #endregion Methods -DataExhange- Specific

 


        #region Methods -Valuation- Specific
        
        /// <summary>
        /// Serialize SoaMethodsDesigner SoaMethodsRequest as text
        /// using SoaDesignerSerializer
        /// </summary>
        /// <param name="req">SoaMethodsRequest</param>
        /// <returns> string</returns>
        public string serializeAsText(ValuationRequest req)
        {
            XDocument doc = new XDocument();
            using (var writer = doc.CreateWriter())
            {
                ValuationSerializer.Serialize(writer, req);
            }
            return doc.ToString();
        }



        public XDocument Valuate(ValuationRequest valuation)
        {
            XDocument resultXdoc = null;
            ValuateRaw valuate = new ValuateRaw();
            valuate.message = serializeAsText(valuation);
            valuateRawResponse1 resp = ServiceValuation.valuateRaw(new valuateRawRequest(valuate));
            if (resp.valuateRawResponse!= null)
            {
                resultXdoc = XDocument.Parse(resp.valuateRawResponse.response);
            }
            return resultXdoc;
        }

        #endregion Methods -Valuation- Specific
    }

}