﻿using System;
using System.Windows;
using System.Net;
using System.Windows.Markup;
using System.Windows.Data;
using System.Globalization;
using System.ComponentModel;

using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Windows.Controls;


namespace Sophis.Web.Api
{
    /// <summary>
    /// For the border around the reference autocompleteBox
    /// </summary>
    public class DateToStringConverter : IValueConverter
    {
        /// <summary>
        /// The Date Format can be specified here
        /// IFor the integrationService, Date format is "yyyy-mm-dd"
        /// ex :2009-08-19
        /// </summary>
        public string FORMAT { get; set; }

        public object Convert(object value,
                           Type targetType,
                           object parameter,
                           CultureInfo culture)
        {

            string dateStr = value.ToString();
            if (dateStr != null)
            {
                try
                {
                    return DateTime.Parse(dateStr);
                }
                catch (Exception e)
                {
                    Logger.Log("DateToStringConverer", "Convert", "error", "UnableTo Parse :" + e.ToString());
                    return value;
                }
            }
            else
            {
                return value;
            }
        }

        public object ConvertBack(object value,
                                  Type targetType,
                                  object parameter,
                                  CultureInfo culture)
        {
            DateTime date = (DateTime)value;
            if (date != null)
            {
                return date.ToString(FORMAT);
            }
            else
            {
                return DateTime.Today.ToString(FORMAT);
            }
        }
    }
}
