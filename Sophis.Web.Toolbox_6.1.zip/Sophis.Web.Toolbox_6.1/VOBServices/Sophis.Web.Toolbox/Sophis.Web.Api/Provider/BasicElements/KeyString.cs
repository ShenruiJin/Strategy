﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Runtime.CompilerServices;
using System.Text;

namespace Sophis.Web.Api
{
    public interface IKeyString<K>
    {
        // Properties
        string DisplayName { get; }
        K Key { get; }
    }



    public class KeyString : IKeyString<int>
    {
        // Fields
        private string _DisplayName;
        private int _Key;

        // Methods
        public KeyString(int key, string name)
        {
            this._Key = key;
            this._DisplayName = name;
        }

        public override string ToString()
        {
            StringBuilder builder = null;
            builder = new StringBuilder();
            builder.Append("[");
            int key = this.Key;
            builder.Append(((int)key).ToString());
            builder.Append(", ");
            if (null != this.DisplayName)
            {
                builder.Append(this.DisplayName);
            }
            builder.Append("]");
            return builder.ToString();
        }

        // Properties
        public virtual string DisplayName
        {
            get{return this._DisplayName;}
        }

        public virtual int Key
        {
            get{ return this._Key;}
        }
    }

 

}
