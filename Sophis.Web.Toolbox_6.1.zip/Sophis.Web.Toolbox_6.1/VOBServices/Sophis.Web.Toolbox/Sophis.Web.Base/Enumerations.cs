﻿using System.ComponentModel;

namespace Sophis.Web.Base
{
    public enum Severity
    {
        [DescriptionAttribute("Debug")]
        Debug,
        [DescriptionAttribute("Info")]
        Info,
        [DescriptionAttribute("Warning")]
        Warning,
        [DescriptionAttribute("Error")]
        Error
    }
}
