﻿using System;
using System.Windows;
using System.Net;
using System.Windows.Markup;
using System.Windows.Data;
using System.Globalization;
using System.ComponentModel;

using System.Collections.Generic;
using System.Text;
using System.Linq;

using System.Windows.Controls;


namespace Sophis.Web.Api
{
    /// <summary>
    /// - Input a string which represent a Date
    ///  Display a string : relative date (ex : -1 d)
    ///  
    /// Supported elements are : 'y' (+/- 1 Year)
    /// 
    /// - Display  a string which is a relative Date
    ///  OutPut : a string which represent a Date
    /// </summary>
    public class RelativeDateToDateAsStringConverter : FrameworkElement, IValueConverter
    {
        /// <summary>
        /// The Date Format can be specified here
        /// IFor the integrationService, Date format is "yyyy-MM-dd"
        /// ex :2009-08-19
        /// Supported Format are 
        /// "d" = short date pattern
        /// "D" = Long Date Pattern
        /// specific format suche as "yyyy-MM-dd" or "yyyy/mm/dd"
        /// </summary>
        [DefaultValue("yyyy-MM-dd")]
        public string FORMAT { get; set; }

        /// <summary>
        /// If not specified, is relative to today
        /// </summary>
        //private DateTime _RELATIVE_TO;

        #region IValueConverter Members
        /// <summary>
        ///  Input a string which represent a Date
        ///  Display a string : relative date (ex : -1 d)
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string dateStr = value.ToString();
            string resultRelativeDate = "0d";
            DateTime inputDate = DateTime.Today;
            DateTime relativeDateTo = DateTime.Today;

            if (dateStr != null)
            {
                try
                {
                    inputDate = DateTime.Parse(dateStr);
                }
                catch (Exception e)
                {
                    Logger.Log("DateToStringConverer", "Convert", "error", "UnableTo Parse :" + e.ToString());
                    return resultRelativeDate;
                }

                if (RELATIVE_TO != DateTime.Today)
                    relativeDateTo = RELATIVE_TO;

                TimeSpan diff = inputDate - relativeDateTo;
                int nbDays = diff.Days;
                if (nbDays != 0)
                {
                    bool isNegative = false;
                    if (nbDays < 0)
                    {
                        isNegative = true;
                        nbDays *= -1;
                    }
                    //If it is less than a month
                    if (nbDays <= 30)
                        resultRelativeDate = (isNegative ? "-" : "") + nbDays.ToString() + "d";
                    //More than a month, Less than a year
                    else if (nbDays > 30 && nbDays < 365)
                    {
                        //The difference is In Month
                        if (relativeDateTo.Day == inputDate.Day)
                        {
                            int nbMonths = 0;
                            //Same Year
                            if (relativeDateTo.Year == inputDate.Year)
                            {
                                nbMonths = inputDate.Month - relativeDateTo.Month;
                            }
                            // We change of year
                            else
                            {
                                if (isNegative)
                                {
                                    nbMonths = 12 - (inputDate.Month - relativeDateTo.Month);
                                    nbMonths *= -1;
                                }
                                else
                                {
                                    nbMonths = (12 - relativeDateTo.Month) + inputDate.Month;
                                }
                            }
                            resultRelativeDate = nbMonths.ToString() + "m";
                        }
                        //the difference is in Days
                        else
                        {
                            resultRelativeDate = (isNegative ? "-" : "") + nbDays.ToString() + "d";
                        }
                    }
                    // More than a year
                    else
                    {
                        //Same DAy
                        if (relativeDateTo.Day == inputDate.Day)
                        {
                            //Same Month ( the diff is ind Year)
                            if (relativeDateTo.Month == inputDate.Month)
                            {
                                int nbYears = inputDate.Year - relativeDateTo.Year;
                                resultRelativeDate = nbYears.ToString() + "y";
                            }
                            //The dif is in Month
                            else
                            {
                                int nbMonths = inputDate.Month - relativeDateTo.Month;
                                resultRelativeDate = nbMonths.ToString() + "m";
                            }
                        }
                    }
                }
            }
            return resultRelativeDate;
        }

        /// <summary>
        /// Display  a string which is a relative Date
        ///  OutPut : a string which represent a Date
        /// </summary>
        /// <param name="value">a string which is a relative Date</param>
        /// <param name="targetType">tpyeof(string)</param>
        /// <param name="parameter">null</param>
        /// <param name="culture">null</param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string relativeDate = (string)value;
            if (relativeDate.Length == 0)
                return DateTime.Today;
            //Paramter Date it is relative to
            DateTime resultDate = DateTime.Today;
            //if (parameter != null)
            //{
            //    DateTime dtparam = (DateTime)parameter;
            //    if (dtparam != null)
            //        resultDate = dtparam;
            //}

            relativeDate = relativeDate.Trim();
            char durationItem = relativeDate[relativeDate.Length - 1];

            int nbTimeframe = 1;
            //If
            if (relativeDate.Length > 1)
            {
                relativeDate = relativeDate.Substring(0, relativeDate.Length - 1);
                int.TryParse(relativeDate, out nbTimeframe);
            }


            if (RELATIVE_TO != DateTime.Today)
                resultDate = RELATIVE_TO;

            switch (durationItem)
            {
                case 'D':
                case 'd':
                    resultDate = resultDate.AddDays(nbTimeframe);
                    break;

                case 'M':
                case 'm':
                    resultDate = resultDate.AddMonths(nbTimeframe);
                    break;

                case 'Y':
                case 'y':
                    resultDate = resultDate.AddYears(nbTimeframe);
                    break;
            }

            return resultDate.ToString(FORMAT);
        }

        public static readonly DependencyProperty RELATIVE_TO_Property = DependencyProperty.Register(
        "RELATIVE_TO", typeof(DateTime), typeof(RelativeDateToDateAsStringConverter),
        null);
        /// <summary>
        /// Get the selected item
        /// 
        /// </summary>
        public DateTime RELATIVE_TO
        {
            get { return (DateTime)GetValue(RELATIVE_TO_Property); }
            set { SetValue(RELATIVE_TO_Property, value); }
        }

        #endregion
    }
}
