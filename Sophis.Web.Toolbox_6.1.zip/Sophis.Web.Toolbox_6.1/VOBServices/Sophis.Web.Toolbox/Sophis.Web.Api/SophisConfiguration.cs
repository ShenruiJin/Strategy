﻿using System;
using System.Net;
using System.IO;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using Sophis.Web.Base;
using System.ComponentModel;

using System.Xml;

namespace Sophis.Web.Api
{
    public class SophisConfiguration : Configuration
    {
        #region Data
        private Uri _DataExchangeAdress = null;
        private Uri _ValuationAdress = null;
        private Uri _SoaMethodDesignerAdress = null;

        private string _SoaPackUserName = string.Empty;
        private string _SoaPackPassword = string.Empty;

        #endregion Data

        #region Constructors

        public SophisConfiguration()
            : base()
        { 
        }

        /// <summary>
        /// The Xmlreader Of the configuration
        /// </summary>
        /// <param name="xmlconfiguration"></param>
        public SophisConfiguration(XmlReader xmlConfiguration)
            :base (xmlConfiguration)
        {
        }

        /// <summary>
        /// Create a new configuration Object.
        /// Use the specified configuration Directory path.
        /// For info :default configuration Directory is the directory of the dll
        /// </summary>
        public SophisConfiguration(string directoryPath)
            :base(directoryPath)
        {
        }

        public SophisConfiguration(Configuration other)
            : base(other)
        {
        }

        #endregion Constructors

        #region Properties

        public Uri SoaMethodDesignerAdress
        {
            get
            {
                if (_SoaMethodDesignerAdress == null && IsConfLoaded && IsSoaMdServiceAvailable)
                    _SoaMethodDesignerAdress = new Uri(_XDocument.Element("configuration").Element("Connection").Element("IntegrationService").Element("Address").Value);
                return _SoaMethodDesignerAdress;
            }
        }
        
        public bool IsSoaMdServiceAvailable
        {
            get
            {
                if (_XDocument.Element("configuration") != null &&
                    _XDocument.Element("configuration").Element("Connection") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("IntegrationService") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("IntegrationService").Element("Address") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("IntegrationService").Element("Address").Value != "")
                    return true;

                return false;
            }
        }


        public Uri DataExchangeAdress
        {
            get
            {
                if (_DataExchangeAdress == null && IsConfLoaded && IsDataExchangeServiceAvailable)
                    _DataExchangeAdress = new Uri(_XDocument.Element("configuration").Element("Connection").Element("DataExchangeService").Element("Address").Value);
                return _DataExchangeAdress;
            }
        }

        public bool IsDataExchangeServiceAvailable
        {
            get
            {
                if (_XDocument.Element("configuration") != null &&
                    _XDocument.Element("configuration").Element("Connection") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("DataExchangeService") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("DataExchangeService").Element("Address") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("DataExchangeService").Element("Address").Value != "")
                    return true;

                return false;
            }
        }

        public Uri ValuationAdress
        {
            get
            {
                if (_ValuationAdress == null && IsConfLoaded && IsValuationServiceAvailable)
                    _ValuationAdress = new Uri(_XDocument.Element("configuration").Element("Connection").Element("ValuationService").Element("Address").Value);
                return _ValuationAdress;
            }
        }

        [DefaultValue(false)]
        public bool IsValuationServiceAvailable
        {
            get
            {
                if (_XDocument.Element("configuration") != null &&
                    _XDocument.Element("configuration").Element("Connection") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("ValuationService") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("ValuationService").Element("Address") != null &&
                    _XDocument.Element("configuration").Element("Connection").Element("ValuationService").Element("Address").Value != "")
                    return true;

                return false;
            }
        }

        [DefaultValue("MANAGER")]        
        public string SoaPackUserName
        {
            get 
            {
                //If Empty, Go in Configuration File to Get it.
                if (_SoaPackUserName == string.Empty)
                {
                    if (_XDocument.Element("configuration") != null &&
                   _XDocument.Element("configuration").Element("SOAPackLogin") != null &&
                   _XDocument.Element("configuration").Element("SOAPackLogin").Element("UserName") != null)
                        _SoaPackUserName = _XDocument.Element("configuration").Element("SOAPackLogin").Element("UserName").Value;
                }
                return _SoaPackUserName; 
            }
            set { _SoaPackUserName = value; }
        }

        public string SoaPackPassword
        {
            get 
            {

                //If Empty, Go in Configuration File to Get it.
                if (_SoaPackPassword == string.Empty)
                {
                    if (_XDocument.Element("configuration") != null &&
                   _XDocument.Element("configuration").Element("SOAPackLogin") != null &&
                   _XDocument.Element("configuration").Element("SOAPackLogin").Element("Password") != null)
                        _SoaPackPassword = _XDocument.Element("configuration").Element("SOAPackLogin").Element("Password").Value;
                }

                return _SoaPackPassword; 
            }
            set { _SoaPackPassword = value; }
        }

        /// <summary>
        /// <ReconnectionDelay>10</ReconnectionDelay>
        /// </summary>
        public TimeSpan ReconnectionDelay
        {
            get
            {
                int nbMin = 10;
                if (_XDocument.Element("configuration") != null &&
                  _XDocument.Element("configuration").Element("Connection") != null &&
                  _XDocument.Element("configuration").Element("Connection").Element("ReconnectionDelay") != null)
                {
                    int.TryParse(_XDocument.Element("configuration").Element("Connection").Element("ReconnectionDelay").Value, out nbMin);
                }
                return (new TimeSpan(0, nbMin, 0));
            }
        }
    

        #endregion Properties

    }
}
