﻿using System;
using System.Net;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Configuration;
using System.Net.Configuration;


namespace Sophis.Web.Base
{
        
    public abstract class Configuration
    {
        #region Data
        /// <summary>
        /// Most important fiels of the class
        /// this Field will be used by the inheriting class to provide Configuration Data
        /// </summary>
        protected XDocument _XDocument { get; private set; }
        
        /// <summary>
        /// Used To Warn Once the Configuration Is loaded
        /// UseFull When ths Loading is asynchronous (Silverlight)
        /// </summary>
        public static event EventHandler ConfigurationLoaded;
        
        /// <summary>
        /// If the copnfiguration Is not loaded
        /// </summary>
        [DefaultValue(false)]
        public bool IsConfLoaded { get; protected set; }
        
        /// <summary>
        /// Default Value is "Path where is located the dll"
        /// The file must be called Sophis.Web.Base.dll.config
        /// </summary>
        public string DirectoryName { get; private set; }

        private string _LogFileName = null;
        private Severity? _LogSeverityLevel = null;

        #endregion Data

        #region Constructors
        /// <summary>
        /// Create a new configuration Object.
        /// Use the default configuration File path= "Resources/configuration.xml";
        /// </summary>
        public Configuration()
        {
            DirectoryName = System.Reflection.Assembly.GetExecutingAssembly().Location; ;
            RetreiveConfiguration();
        }

        /// <summary>
        /// Create a new configuration Object.
        /// Use the specified configuration Directory path.
        /// For info :default configuration Directory is the directory of the dll
        /// </summary>
        public Configuration(string directoryPath)
        {
            DirectoryName = directoryPath;
            RetreiveConfiguration();
        }


        /// <summary>
        /// Create a new configuration Object 
        /// use the XmlReader to create the Configuration Object
        /// </summary>
        /// <param name="xmlConfiguration"></param>
        public Configuration(XmlReader xmlConfiguration)
        {
            RetreiveConfiguration(xmlConfiguration);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="otherConf"></param>
        public Configuration(Configuration otherConf)
        {
            DirectoryName = otherConf.DirectoryName;
            _XDocument = otherConf._XDocument;
        }
        #region Constructor - .NET Specific

        public Configuration(DirectoryInfo directoryInfo)
        {
            DirectoryName = directoryInfo.FullName;
            RetreiveConfiguration();
        }
        #endregion Constructor - .NET Specific

        #endregion Constructors

        #region Properties



        public string LogFileName
        {
            get
            {
                if (_LogFileName == null)
                {
                    if ((_XDocument.Element("configuration") != null) && (_XDocument.Element("configuration").Element("Log") != null) && (_XDocument.Element("configuration").Element("Log").Element("File") != null))
                    {
                        _LogFileName = _XDocument.Element("configuration").Element("Log").Element("File").Value;
                        if (!Path.IsPathRooted(_LogFileName))
                            _LogFileName = Path.Combine(GetLogBaseDirectory(), _LogFileName);
                    }
                }
                return _LogFileName;
            }
        }

        public FileInfo LogFile
        {
            get
            {
                return new FileInfo(LogFileName);
            }
        }


        public Severity? LogSeverityLevel
        {
            get
            {
                if (_LogSeverityLevel == null)
                {
                    if ((_XDocument.Element("configuration") != null) && (_XDocument.Element("configuration").Element("Log") != null) && (_XDocument.Element("configuration").Element("Log").Element("SeverityLevel") != null))
                        _LogSeverityLevel = (Severity)Enum.Parse(typeof(Severity), _XDocument.Element("configuration").Element("Log").Element("SeverityLevel").Value,true);
                }
                return _LogSeverityLevel;
            }
        }

        #endregion Properties

        #region Initialisation

        /// <summary>
        /// Retreive Xdocument Configuration, 
        /// Asynchrounsly if in Silverlight, or Directly From DIsk If we are in .Net
        /// </summary>
        private void RetreiveConfiguration()            
        {
            System.Configuration.Configuration config = System.Configuration.ConfigurationManager.OpenExeConfiguration(DirectoryName);

            using (StreamReader s = new StreamReader(new FileStream(config.FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
            {
                RetreiveConfiguration(XmlReader.Create(s));
                s.Close();
            }
            client_OpenReadCompleted(null, null);
        }

        private void client_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            OnConfigurationLoaded(new EventArgs());
        }
        protected void RetreiveConfiguration(XmlReader xmlReader)
        {
            _XDocument = XDocument.Load(xmlReader);
            OnConfigurationLoaded(new EventArgs());
        }

        protected void OnConfigurationLoaded(EventArgs events)
        {
            IsConfLoaded = true;

            if (ConfigurationLoaded != null)
                ConfigurationLoaded(this, events);
        }
        #endregion Initialisation

        public virtual string GetLogBaseDirectory()
        {
            return "";
        }

    }
}
