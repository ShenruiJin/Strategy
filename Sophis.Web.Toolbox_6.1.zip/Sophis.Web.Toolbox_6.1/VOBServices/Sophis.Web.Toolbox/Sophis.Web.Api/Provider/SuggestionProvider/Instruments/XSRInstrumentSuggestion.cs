﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;


namespace Sophis.Web.Api
{
    public class XSRInstrumentSuggestion : Suggestion
    {
        private string _InstrumentType = string.Empty;
        private string _InstrumentSico = string.Empty;

        public XSRInstrumentSuggestion(string reference, string sico, string name, string type, int prefixLength)
            : base(reference, name, prefixLength)
        {
            _InstrumentSico = sico;
            _InstrumentType = type;
        }

        public string InstrumentType
        {
            get { return _InstrumentType; }
        }
        public string InstrumentSico
        {
            get { return _InstrumentSico; }
        }

    }
}
