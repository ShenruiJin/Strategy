using System;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Xml;
using System.Xml.Linq;
using System.Linq;
using Sophis.Web.Api;
using Sophis.Web.Objects;
using sophis.services;

using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

namespace SophisSOAFunctions
{
    [GuidAttribute("3929A249-9631-44cd-BD12-9CA5B80F3527"),
    ProgId("SophisSOA.Functions"),
    ClassInterface(ClassInterfaceType.AutoDual)]
    [ComVisible(true)]
    public class SophisSOAFunctions
    {

        Excel._Worksheet _CurentWorkSheet = null;

        public SophisSOAFunctions()
        {
            //Windows regionnal settings and excel settings must be coherent (for example if windows regionnal settings are french,
            //excel has to contain the 'french package'. This is not always true.
            //So force the regionnal settings to US, contain in every Excel installation.
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
        }

        #region data_exchange

        public void ExportInstrument(Excel._Worksheet sheet)
        {
            try
            {
                Object instToExport = Sophis.Web.Objects.WebDataExchange.GetInstrumentToExport(Convert.ToString(((Excel.Range)sheet.Cells[1, 1]).Value2), Sophis.Web.Objects.Utils.MainReferenceType);
                ExportMessage expMessage = Sophis.Web.Objects.WebDataExchange.GetExportMessage(new Object[] { instToExport }, BatchType.AllRegardlessOfErrors);
                XDocument exportAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Export(expMessage);
                
                //XAttribute att = exportAnswer.Root.Element(NS.nsInstrument + "instrument").Attribute(NS.xsi + "type");
                
                if (exportAnswer != null && exportAnswer.Root.Element(NS.nsDataExchange + "elementRejected") != null)
                {
                    XElement xElementRejected = exportAnswer.Root.Element(NS.nsDataExchange + "elementRejected");
                    if (xElementRejected != null)
                    {
                        WriteErrorMessage(sheet, 4, 1, xElementRejected, NS.fpml);
                    }
                }
                else if (exportAnswer != null && exportAnswer.Root.Element(NS.nsInstrument + "share") != null)
                {
                    XElement xShare = exportAnswer.Root.Element(NS.nsInstrument + "share");
                    if (xShare != null)
                    {
                        sheet.Cells[4, 1] = "Internal Id";
                        sheet.Cells[4, 2] = xShare.Element(NS.nsInstrument + "identifier").Element(NS.nsInstrument + "sophis").Value;
                        sheet.Cells[5, 1] = "Name";
                        sheet.Cells[5, 2] = xShare.Element(NS.nsInstrument + "name").Value;
                        sheet.Cells[6, 1] = "Currency";
                        sheet.Cells[6, 2] = xShare.Element(NS.nsInstrument + "currency").Value;
                    }
                }
                else if (exportAnswer != null && exportAnswer.Root.Element(NS.nsInstrument + "instrument") != null)
                {
                    XElement xInstrument = exportAnswer.Root.Element(NS.nsInstrument + "instrument");
                    if (xInstrument != null)
                    {
                        sheet.Cells[4, 1] = "Internal Id";
                        sheet.Cells[4, 2] = xInstrument.Element(NS.nsInstrument + "identifier").Element(NS.nsInstrument + "sophis").Value;
                        sheet.Cells[5, 1] = "Name";
                        sheet.Cells[5, 2] = xInstrument.Element(NS.nsInstrument + "name").Value;
                        sheet.Cells[6, 1] = "Currency";
                        sheet.Cells[6, 2] = xInstrument.Element(NS.nsInstrument + "currency").Value;
                        sheet.Cells[7, 3] = xInstrument.ToString();
                    }
                }
                else if (exportAnswer != null && exportAnswer.Root.Element(NS.nsFund + "internalFund") != null)
                {
                    XElement xFund = exportAnswer.Root.Element(NS.nsFund + "internalFund");
                    if (xFund != null)
                    {
                        sheet.Cells[4, 1] = "Internal Id";
                        sheet.Cells[4, 2] = xFund.Element(NS.nsInstrument + "identifier").Element(NS.nsInstrument + "sophis").Value;
                        sheet.Cells[5, 1] = "Name";
                        sheet.Cells[5, 2] = xFund.Element(NS.nsInstrument + "name").Value;
                        sheet.Cells[6, 1] = "Currency";
                        sheet.Cells[6, 2] = xFund.Element(NS.nsInstrument + "currency").Value;
                        XElement idents = xFund.Element(NS.nsInstrument + "identifier");
                        if (idents != null && idents.Descendants() != null)
                        {
                            foreach (XElement elem in (idents.Descendants()))
                            {
                                if (elem.Attribute(NS.nsInstrument + "name") != null )
                                {
                                    if (elem.Attribute(NS.nsInstrument + "name").Value == "Isin")
                                    {
                                        sheet.Cells[7, 1] = "Isin";
                                        sheet.Cells[7, 2] = elem.Value;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                sheet.Cells[4, 1] = "Exception";
                sheet.Cells[5, 1] = ex.Message;
            }   
        }

        public void ImportTradeOnSwap(Excel._Worksheet sheet)
        {
            CleanErrorMessage(sheet, 4, 4);
            try
            {
                Swap oneSwap = CreateSwap(sheet);
                Trade oneTrade = Sophis.Web.Objects.WebTransaction.GetTransactionOnProduct(1000, 99, "EUR", "Purchase/Sale", "ROOT:Test", "Entity2", "ct", "tt", new DateTime(1,1,1), "IS");

                ImportMessage impMessage = Sophis.Web.Objects.WebTransaction.CreateTransactionOnInstrument(oneSwap, oneTrade);
                XDocument importAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Import(impMessage);

                if (importAnswer != null && importAnswer.Root.Name == NS.nsDataExchange + "messageRejected")
                {
                    WriteErrorMessage(sheet, 4, 4, importAnswer.Root, NS.fpml);
                }
                else if (importAnswer != null && importAnswer.Root.Element(NS.nsInstrument + "instrumentIdentifier") != null)
                {
                    XElement xResp = importAnswer.Root.Element(NS.nsInstrument + "instrumentIdentifier");
                    if (xResp != null)
                    {
                        sheet.Cells[4, 4] = "Internal Id";
                        sheet.Cells[4, 5] = xResp.Element(NS.nsInstrument + "sophis").Value;
                    }
                }

            }
            catch (Exception ex)
            {
                sheet.Cells[4, 4] = "Exception";
                sheet.Cells[4, 5] = ex.Message;
            }
        }
        
        public void ImportSwap(Excel._Worksheet sheet)
        {
            CleanErrorMessage(sheet, 4, 4);
            try
            {
                Swap oneSwap = CreateSwap(sheet);
                ImportMessage impMessage = Sophis.Web.Objects.WebDataExchange.GetImportMessage(new Object[] { oneSwap }, BatchType.AllRegardlessOfErrors);
                XDocument importAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Import(impMessage);

                if (importAnswer != null && importAnswer.Root.Name == NS.nsDataExchange + "messageRejected")
                {
                    WriteErrorMessage(sheet, 4, 4, importAnswer.Root, NS.fpml);
                }
                else if (importAnswer != null && importAnswer.Root.Element(NS.nsInstrument + "instrumentIdentifier") != null)
                {
                    XElement xResp = importAnswer.Root.Element(NS.nsInstrument + "instrumentIdentifier");
                    if (xResp != null)
                    {
                        sheet.Cells[4, 4] = "Internal Id";
                        sheet.Cells[4, 5] = xResp.Element(NS.nsInstrument + "sophis").Value;
                    }
                }
                else
                {
                    sheet.Cells[4, 4] = importAnswer.ToString();
                }

            }
            catch (Exception ex)
            {
                sheet.Cells[4, 4] = "Exception";
                sheet.Cells[4, 5] = ex.Message;
            }
        }

        public void GetStaticData(Excel._Worksheet sheet, int column)
        {
            try
            {
                List<Sophis.Web.Api.SoaMethodParameter> parameters = new List<Sophis.Web.Api.SoaMethodParameter>();
                Sophis.Web.Api.SoaMethodParameter paramMethod = new Sophis.Web.Api.SoaMethodParameter();
                paramMethod.name = "MethodName";
                paramMethod.Value = Convert.ToString(((Excel.Range)sheet.Cells[1, column]).Value2);
                parameters.Add(paramMethod);
                Sophis.Web.Api.SoaMethodParameter paramType = new Sophis.Web.Api.SoaMethodParameter();
                paramType.name = "TypeName";
                paramType.Value = Convert.ToString(((Excel.Range)sheet.Cells[2, column]).Value2);
                parameters.Add(paramType);
                Sophis.Web.Api.SoaMethodParameter paramAssambly = new Sophis.Web.Api.SoaMethodParameter();
                paramAssambly.name = "AssemblyName";
                paramAssambly.Value = Convert.ToString(((Excel.Range)sheet.Cells[3, column]).Value2);
                parameters.Add(paramAssambly);
                XDocument xDoc = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().ExecuteMethod("ObjectDataProvider", parameters);
                
                int line = 4;
                if (xDoc != null &&
                   (xDoc.FirstNode as XElement) != null &&
                   ((xDoc.FirstNode as XElement).FirstNode as XElement) != null &&
                   (((xDoc.FirstNode as XElement).FirstNode as XElement).Descendants()) != null)
                {
                    foreach (XElement elem in ((xDoc.FirstNode as XElement).FirstNode as XElement).Descendants())
                    {
                        sheet.Cells[line, column] = elem.Value;
                        line++;
                    }
                }

            }
            catch (Exception ex)
            {
                sheet.Cells[4, 4] = "Exception";
                sheet.Cells[4, 5] = ex.Message;
            }
        }

        public void GetInstrumentList(Excel._Worksheet sheet)
        {
            try
            {
                List<Sophis.Web.Api.SoaMethodParameter> parameters = new List<Sophis.Web.Api.SoaMethodParameter>();
                Sophis.Web.Api.SoaMethodParameter paramType = new Sophis.Web.Api.SoaMethodParameter();
                paramType.name = "IstrType";
                paramType.Value = Convert.ToString(((Excel.Range)sheet.Cells[1, 2]).Value2);
                parameters.Add(paramType);
                Sophis.Web.Api.SoaMethodParameter paramCcy = new Sophis.Web.Api.SoaMethodParameter();
                paramCcy.name = "CcyIso";
                paramCcy.Value = Convert.ToString(((Excel.Range)sheet.Cells[2, 2]).Value2);
                parameters.Add(paramCcy);
                Sophis.Web.Api.SoaMethodParameter prefix = new Sophis.Web.Api.SoaMethodParameter();
                prefix.name = "Prefix";
                prefix.Value = "";
                parameters.Add(prefix);
                Sophis.Web.Api.SoaMethodParameter nbMax = new Sophis.Web.Api.SoaMethodParameter();
                nbMax.name = "NbMax";
                nbMax.Value = "10000";
                parameters.Add(nbMax);
                XDocument xDoc = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().ExecuteMethod("InstrumentList", parameters);

                int line = 4;
                //TODO: display result
                if (xDoc != null &&
                   (xDoc.FirstNode as XElement) != null &&
                   ((xDoc.FirstNode as XElement).FirstNode as XElement) != null &&
                   (((xDoc.FirstNode as XElement).FirstNode as XElement).Descendants()) != null)
                {
                    foreach (XElement elem in (xDoc.FirstNode as XElement).Descendants())
                    {

                        if (elem.Name.LocalName.ToString() == "Reference")
                        {
                            sheet.Cells[line, 5] = elem.Value;
                            line++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                sheet.Cells[4, 4] = "Exception";
                sheet.Cells[4, 5] = ex.Message;
            }
        }

        public void GetUnderlyingData(Excel._Worksheet sheet)
        {

            try
            {
                int line = 5;
                //Get the dividends
                Object divToExport = Sophis.Web.Objects.WebMarketData.GetDividendsExportObject(Convert.ToString(((Excel.Range)sheet.Cells[1, 2]).Value2));
                ExportMessage expMessage = Sophis.Web.Objects.WebDataExchange.GetExportMessage(new Object[] { divToExport }, BatchType.AllRegardlessOfErrors);
                XDocument exportAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Export(expMessage);
                if (exportAnswer != null && exportAnswer.Root.Element(NS.nsDataExchange + "elementRejected") != null)
                {
                    XElement xElementRejected = exportAnswer.Root.Element(NS.nsDataExchange + "elementRejected");
                    if (xElementRejected != null)
                    {
                        WriteErrorMessage(sheet, 4, 1, xElementRejected, NS.fpml);
                    }
                }
                else if (exportAnswer != null)//&& 
                {
                    //(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")//(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")
                    List<XElement> listDivids = (from d in exportAnswer.Root.Descendants(NS.nsDividend + "dividend")
                                                 select d).ToList();


                    sheet.Cells[line, 1] = "dividend Type";
                    sheet.Cells[line, 2] = "dividend Date";
                    sheet.Cells[line, 3] = "dividend Value";
                    line++;
                    foreach (XElement elem in listDivids)
                    {
                        sheet.Cells[line, 1] = elem.Element(NS.nsDividend + "dividendNatureType").Value;
                        sheet.Cells[line, 2] = elem.Element(NS.nsDividend + "recordDate").Value;
                        sheet.Cells[line, 3] = elem.Element(NS.nsDividend + "value").Value;

                        line++;
                    }
                }
                line++;
                line++;

                Object volatToExport = Sophis.Web.Objects.WebMarketData.GetVolatilitiesExportObject(Convert.ToString(((Excel.Range)sheet.Cells[1, 2]).Value2));
                expMessage = Sophis.Web.Objects.WebDataExchange.GetExportMessage(new Object[] { volatToExport }, BatchType.AllRegardlessOfErrors);
                exportAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Export(expMessage);
                if (exportAnswer != null && exportAnswer.Root.Element(NS.nsDataExchange + "elementRejected") != null)
                {
                    XElement xElementRejected = exportAnswer.Root.Element(NS.nsDataExchange + "elementRejected");
                    if (xElementRejected != null)
                    {
                        WriteErrorMessage(sheet, 4, 1, xElementRejected, NS.fpml);
                    }
                }
                else if (exportAnswer != null)//&& 
                {
                    //(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")//(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")
                    List<XElement> listVolats = (from d in exportAnswer.Root.Descendants(NS.nsVolatility + "volatilityPoint")
                                                 select d).ToList();

                    sheet.Cells[line, 1] = "Date";
                    sheet.Cells[line, 2] = "ATM Value";
                    sheet.Cells[line, 3] = "Strike";
                    sheet.Cells[line, 4] = "Value";
                    line++;
                    foreach (XElement elem in listVolats)
                    {
                        try
                        {
                            //XElement ee = elem.Element(NS.nsVolatility + "volatilityPoint");
                            //XElement ee2 = elem.Element(NS.nsCommon + "date");
                            XElement ee2 = elem.Element(NS.nsVolatility + "date");
                            //string nb = elem.Element(NS.nsVolatility + "volatilityPoint").Element(NS.nsVolatility + "date").Element(NS.nsCommon + "relativeDate").Element(NS.nsCommon + "periodMultiplier").Value;
                            string nb = elem.Element(NS.nsVolatility + "date").Element(NS.nsCommon2 + "relativeDate").Element(NS.nsCommon2 + "periodMultiplier").Value;
                            string type = elem.Element(NS.nsVolatility + "date").Element(NS.nsCommon2 + "relativeDate").Element(NS.nsCommon2 + "periodEnum").Value;
                            sheet.Cells[line, 1] = nb + " " + type;
                            sheet.Cells[line, 2] = elem.Element(NS.nsVolatility + "atTheMoney").Value;
                            XElement elemSmile = elem.Element(NS.nsVolatility + "smile");
                            if (elemSmile != null)
                            {
                                //foreach (XElement oneSmile in elemSmile.Descendants())
                                foreach (XElement oneSmile in elemSmile.Elements(NS.nsVolatility + "smilePoint"))
                                {
                                    sheet.Cells[line, 3] = oneSmile.Element(NS.nsVolatility + "strike").Value;
                                    sheet.Cells[line, 4] = oneSmile.Element(NS.nsVolatility + "value").Value;
                                    line++;
                                }
                            }
                            line++;
                        }
                        catch
                        {
                        }
                        line++;
                    }
                }
            }
            catch (Exception ex)
            {
                sheet.Cells[4, 1] = "Exception";
                sheet.Cells[5, 1] = ex.Message;
            }
        }


#endregion data_exchange

        #region option_valuation

        public void PriceOption(Excel._Worksheet sheet)
        {
            try
            {
                string underlying = Convert.ToString(((Excel.Range)sheet.Cells[1, 2]).Value2);
                string Ccy = Convert.ToString(((Excel.Range)sheet.Cells[2, 2]).Value2);
                DateTime maturity = Convert.ToDateTime(((Excel.Range)sheet.Cells[3, 2]).Value2);
                double strike = Convert.ToDouble(((Excel.Range)sheet.Cells[4, 2]).Value2);

                Strike wStrike = Sophis.Web.Objects.Utils.GetMoneyStrike(strike, Ccy); ;
                EquityOption wOption = Sophis.Web.Objects.WebOption.CreateEquityOption("", "", underlying, Ccy, maturity, null, "Trinomial", "General", null);

                ValuationRequest wRequest = Sophis.Web.Objects.WebValuation.GetDerivativeValuationRequest(wOption);
                
                XDocument respValuation = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Valuate(wRequest);

            }
            catch (Exception ex)
            {
                sheet.Cells[4, 4] = "Exception";
                sheet.Cells[4, 5] = ex.Message;
            }
        }

        #endregion option_valuation

        #region basketOption_Valuation

        public void PriceBasketOption(Excel._Worksheet sheet)
        {

            try
            {
                Basket components = GetComponents(sheet, 2, 2);
                Index virtualBasket = WebIndex.GetIndex("", "virtual", "EUR", components);

                virtualBasket.id = "basket";

                DateTime valuationDate = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[7, 2]).Value2));

                DateTime maturity = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[8, 2]).Value2));

                double strike = Convert.ToDouble(((Excel.Range)sheet.Cells[9, 2]).Value2.ToString());
                
                //Create the option
                //Strike strikeObj = Utils.GetStrikePercentage(1, strike, valuationDate);
                Strike strikeObj = Utils.GetMoneyStrike(strike, "EUR");
                
                EquityOption option = WebOption.CreateEquityOption("", "", "", "EUR", maturity, strikeObj, "Trinomial", "Standard", null);

                option.underlyer.reference = null;
                option.underlyer.href = "basket";

                ValuationRequest valRequest = WebValuation.PriceInstruments(new object[] { option, virtualBasket});
                XDocument valAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Valuate(valRequest);


                if (valAnswer != null && valAnswer.Root.Element(NS.nsDataExchange + "elementRejected") != null)
                {
                    XElement xElementRejected = valAnswer.Root.Element(NS.nsDataExchange + "elementRejected");
                    if (xElementRejected != null)
                    {
                        WriteErrorMessage(sheet, 4, 1, xElementRejected, NS.fpml);
                    }
                }
                else if (valAnswer != null)
                {
                    //(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")//(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")
                    List<XElement> listDerivarives = (from d in valAnswer.Root.Descendants(NS.nsValuation + "derivative")
                                                      select d).ToList();
                    int line = 15;
                    foreach (XElement elem in listDerivarives)
                    {
                        try
                        {
                            //XElement ee = elem.Element(NS.nsVolatility + "volatilityPoint");
                            //XElement ee2 = elem.Element(NS.nsCommon + "date");
                            string type = elem.Attribute(NS.nsValuation + "derivativeScheme").Value.ToString();
                            type = type.Substring(36);
                            sheet.Cells[line, 8] = type;
                            try
                            {
                                sheet.Cells[line, 9] = Convert.ToDouble(elem.Element(NS.nsValuation + "value").Value);
                            }
                            catch
                            {
                                sheet.Cells[line, 9] = "#IND";
                            }
                            line++;
                        }
                        catch
                        {
                            line++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                sheet.Cells[4, 1] = "Exception";
                sheet.Cells[5, 1] = ex.Message;
            }
        }

        public void BookBasketOption(Excel._Worksheet sheet)
        {

            try
            {
                string name = ((Excel.Range)sheet.Cells[3, 9]).Value2.ToString();

                Basket components = GetComponents(sheet, 2, 2);
                Index basket = WebIndex.GetIndex(name + "_Basket", name + "_Basket", "EUR", components);
                
                ImportMessage impMessage = Sophis.Web.Objects.WebDataExchange.GetImportMessage(new Object[] { basket }, BatchType.AllOrNothing);
                XDocument importAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Import(impMessage);

                if (importAnswer != null && importAnswer.Root.Name == NS.nsDataExchange + "messageRejected")
                {
                    WriteErrorMessage(sheet, 40, 15, importAnswer.Root, NS.fpml);
                }
                else if (importAnswer != null && importAnswer.Root.Element(NS.nsInstrument + "instrumentIdentifier") != null)
                {
                    //Create the option
                    DateTime valuationDate = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[7, 2]).Value2));

                    DateTime maturity = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[8, 2]).Value2));

                    double strike = Convert.ToDouble(((Excel.Range)sheet.Cells[9, 2]).Value2.ToString());

                    //Create the option
                    //Strike strikeObj = Utils.GetStrikePercentage(1, strike, valuationDate);
                    Strike strikeObj = Utils.GetMoneyStrike(strike, "EUR");

                    EquityOption option = WebOption.CreateEquityOption(name + "_Option", name + "_Option", "", "EUR", maturity, strikeObj, "Trinomial", "Standard", null);
                    

                    option.underlyer.href = null;
                    option.underlyer.reference = Utils.GetReference(name+"_Basket", Utils.MainReferenceType);
                    option.id = "option";

                    string folio = ((Excel.Range)sheet.Cells[5, 9]).Value2.ToString();
                    double spot = Convert.ToDouble(((Excel.Range)sheet.Cells[6, 9]).Value2);
                    string ctpy = ((Excel.Range)sheet.Cells[7, 9]).Value2.ToString();
                    Trade oneTrade = Sophis.Web.Objects.WebTransaction.GetTransactionOnProduct(1, spot, "EUR", "Purchase/Sale", folio, "Entity 2", ctpy, option.name, valuationDate, "IS"); ;
                    TradeProduct tradeOnProduct = oneTrade.Item as TradeProduct;
                    if (null != tradeOnProduct)
                    {
                        tradeOnProduct.instrument = new TradeInstrument();
                        tradeOnProduct.instrument.href = "option";
                    }

                    ImportMessage impMessage2 = Sophis.Web.Objects.WebDataExchange.GetImportMessage(new Object[] { option, oneTrade }, BatchType.AllOrNothing);
                    XDocument importAnswer2 = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Import(impMessage2);

                    if (importAnswer2.Root.Element(NS.nsTrade + "tradeReference") != null)
                    {
                        sheet.Cells[37, 9] = importAnswer2.Root.Element(NS.nsTrade + "tradeReference").Element(NS.nsTrade + "tradeId").Value;
                    }
                    else
                    {
                        sheet.Cells[40, 15] = importAnswer2.ToString();
                    }
                }
                else
                {
                    sheet.Cells[40, 15] = importAnswer.ToString();
                }
            }
            catch (Exception ex)
            {
                sheet.Cells[40, 15] = "Exception";
                sheet.Cells[41, 15] = ex.Message;
            }
        }

        private Basket GetComponents(Excel._Worksheet sheet, int startLine, int startColumn)
        {
            Basket basket = new Basket();
            
            List<BasketComponent> components = new List<BasketComponent>();
            while(1==1)
            {
                try
                {
                    string compName = ((Excel.Range)sheet.Cells[startLine, startColumn]).Value2.ToString();
                    double qty = Convert.ToDouble(((Excel.Range)sheet.Cells[startLine, startColumn+1]).Value2);
                    startLine++;
                    components.Add(new BasketComponent()
                                    {
                                        instrument = new Underlyer()
                                        {
                                            reference = Utils.GetReference(compName, Utils.MainReferenceType)
                                        },
                                        quantity = qty
                                     }
                                  );
                }
                catch
                {
                    break;
                }
            }
            basket.basketComponent = components.ToArray();
            
            return basket;
        }

        #endregion basketOption_Valuation

        #region package_valuation
        public void PricePackage(Excel._Worksheet sheet)
        {

            try
            {
               EquityOption option = GetOption(sheet);
               option.id = "option";
                //Create the bond
               Bond bond = GetBond(sheet);
               bond.id = "bond";

                //Create the package
               Package pack = GetPackage(sheet);
               pack.basket.basketComponent[0].instrument.href = "bond";
               pack.basket.basketComponent[1].instrument.href = "option";

                ValuationRequest valRequest = WebValuation.PriceInstruments(new object[] { bond, option, pack });
                XDocument valAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Valuate(valRequest);


                if (valAnswer != null && valAnswer.Root.Element(NS.nsDataExchange + "elementRejected") != null)
                {
                    XElement xElementRejected = valAnswer.Root.Element(NS.nsDataExchange + "elementRejected");
                    if (xElementRejected != null)
                    {
                        WriteErrorMessage(sheet, 4, 1, xElementRejected, NS.fpml);
                    }
                }
                else if (valAnswer != null) 
                {
                    //(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")//(from d in exportAnswer.Root.Element(NS.nsValuation + "market").Element(NS.nsValuation + "pricingStructureValuation").Element(NS.nsDividends + "dividends").Element(NS.nsDividends + "dividendList").Elements(NS.nsDividends + "dividend")
                    List<XElement> listDerivarives = (from d in valAnswer.Root.Descendants(NS.nsValuation + "derivative")
                                                 select d).ToList();
                    int line = 15;
                    foreach (XElement elem in listDerivarives)
                    {
                        try
                        {
                            //XElement ee = elem.Element(NS.nsVolatility + "volatilityPoint");
                            //XElement ee2 = elem.Element(NS.nsCommon + "date");
                            string type = elem.Attribute(NS.nsValuation + "derivativeScheme").Value.ToString();
                            type = type.Substring(36);
                            sheet.Cells[line, 8] = type;
                            try
                            {
                                sheet.Cells[line, 9] = Convert.ToDouble(elem.Element(NS.nsValuation + "value").Value);
                            }
                            catch
                            {
                                sheet.Cells[line, 9] = "#IND";
                            }
                            line++;
                        }
                        catch
                        {
                            line++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                sheet.Cells[4, 1] = "Exception";
                sheet.Cells[5, 1] = ex.Message;
            }
        }

        public void BookPackage(Excel._Worksheet sheet)
        {

            try
            {
                string name = ((Excel.Range)sheet.Cells[31, 9]).Value2.ToString();
                EquityOption option = GetOption(sheet);
                option.name = name + "_opt";
                option.identifier = new Identifier();
                option.identifier.reference = Utils.GetReference(option.name, Utils.MainReferenceType);
               

                //Create the bond
                Bond bond = GetBond(sheet);
                bond.name = name + "_bond";
                bond.identifier = new Identifier();
                bond.identifier.reference = Utils.GetReference(bond.name, Utils.MainReferenceType);

               
                ImportMessage impMessage = Sophis.Web.Objects.WebDataExchange.GetImportMessage(new Object[] { bond, option}, BatchType.AllOrNothing);
                XDocument importAnswer = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Import(impMessage);

                if (importAnswer != null && importAnswer.Root.Name == NS.nsDataExchange + "messageRejected")
                {
                    WriteErrorMessage(sheet, 40, 15, importAnswer.Root, NS.fpml);
                }
                else if (importAnswer != null && importAnswer.Root.Element(NS.nsInstrument + "instrumentIdentifier") != null)
                {
                  

                    //Create the package
                    Package pack = GetPackage(sheet);
                    pack.basket.basketComponent[0].instrument.reference = Utils.GetReference(bond.name, Utils.MainReferenceType);
                    pack.basket.basketComponent[1].instrument.reference = Utils.GetReference(option.name, Utils.MainReferenceType);

                    pack.name = name + "_pack";
                    pack.identifier = new Identifier();
                    pack.identifier.reference = Utils.GetReference(pack.name, Utils.MainReferenceType);
                    pack.id = "package";
                    
                    DateTime valuationDate = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[2, 9]).Value2));
                    string folio = ((Excel.Range)sheet.Cells[33, 9]).Value2.ToString();
                    double spot = Convert.ToDouble(((Excel.Range)sheet.Cells[34, 9]).Value2);
                    string ctpy = ((Excel.Range)sheet.Cells[35, 9]).Value2.ToString();
                    Trade oneTrade = Sophis.Web.Objects.WebTransaction.GetTransactionOnProduct(1, spot, "EUR", "Purchase/Sale", folio, "Sophis", ctpy, pack.name, valuationDate, "MANAGER"); ;
                    TradeProduct tradeOnProduct = oneTrade.Item as TradeProduct;
                    if (null != tradeOnProduct)
                    {
                        tradeOnProduct.instrument = new TradeInstrument();
                        tradeOnProduct.instrument.href = "package";
                    }

                    ImportMessage impMessage2 = Sophis.Web.Objects.WebDataExchange.GetImportMessage(new Object[] { pack, oneTrade}, BatchType.AllOrNothing);
                    XDocument importAnswer2 = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Import(impMessage2);

                    if (importAnswer2.Root.Element(NS.nsTrade + "tradeReference") != null)
                    {
                        sheet.Cells[37, 9] = importAnswer2.Root.Element(NS.nsTrade + "tradeReference").Element(NS.nsTrade + "tradeId").Value;
                    }
                    else
                    {
                        sheet.Cells[40, 15] = importAnswer2.ToString();
                    }
                }
                else
                {
                    sheet.Cells[40, 15] = importAnswer.ToString();
                }
            }
            catch (Exception ex)
            {
                sheet.Cells[40, 15] = "Exception";
                sheet.Cells[41, 15] = ex.Message;
            }
        }


        Bond GetBond(Excel._Worksheet sheet)
        {
            DateTime valuationDate = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[2, 9]).Value2));

            DateTime maturity = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[3, 9]).Value2));

            double bondRate = Convert.ToDouble(((Excel.Range)sheet.Cells[5, 9]).Value2.ToString());
            double bondNotional = Convert.ToDouble(((Excel.Range)sheet.Cells[6, 9]).Value2.ToString());

            //Create the bond
            Bond bond = WebBond.CreateBond("", "", "EUR", bondRate, bondNotional, valuationDate, maturity);
           

            return bond;
        }

        EquityOption GetOption(Excel._Worksheet sheet)
        {
            DateTime valuationDate = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[2, 9]).Value2));

            DateTime maturity = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[3, 9]).Value2));

            double barrierLevel = Convert.ToDouble(((Excel.Range)sheet.Cells[8, 9]).Value2.ToString());
            double strike = Convert.ToDouble(((Excel.Range)sheet.Cells[9, 9]).Value2.ToString());

            ////Get the stock parameters in the worksheet
            string underlyingRef = ((Excel.Range)sheet.Cells[1, 2]).Value2.ToString();

            //Create the option
            //Strike strikeObj = Utils.GetStrikePercentage(1, strike, valuationDate);
            Strike strikeObj = Utils.GetMoneyStrike(strike, "EUR");
            Feature[] clauses = null;
            clauses = new Feature[1];
            clauses[0] = Utils.GetOneBarrier(valuationDate, maturity, barrierLevel, 5, "");

            EquityOption option = WebOption.CreateEquityOption("", "", underlyingRef, "EUR", maturity, strikeObj, "Trinomial", "Old general", clauses);

            return option;
        }

        Package GetPackage(Excel._Worksheet sheet)
        {
            DateTime valuationDate = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[2, 9]).Value2));

            DateTime maturity = DateTime.FromOADate(Convert.ToDouble(((Excel.Range)sheet.Cells[3, 9]).Value2));

            double qtyBond = Convert.ToDouble(((Excel.Range)sheet.Cells[11, 9]).Value2);

            double qtyOption = Convert.ToDouble(((Excel.Range)sheet.Cells[12, 9]).Value2);


            //Create the package
            Package pack = WebPackage.GetPackage("", "k", "EUR");
            pack.basket = new Basket();
            pack.basket.basketComponent = new BasketComponent[2];
            pack.basket.basketComponent[0] = new BasketComponent();
            pack.basket.basketComponent[0].instrument = new Underlyer();
            pack.basket.basketComponent[0].quantity = qtyBond;

            pack.basket.basketComponent[1] = new BasketComponent();
            pack.basket.basketComponent[1].instrument = new Underlyer();
            pack.basket.basketComponent[1].quantity = qtyOption;

            return pack;
        }

  

        protected Swap CreateSwap(Excel._Worksheet sheet)
        {
            try
            {
                string refe = Convert.ToString(((Excel.Range)sheet.Cells[1, 2]).Value2);
                string name = Convert.ToString(((Excel.Range)sheet.Cells[2, 2]).Value2);
                string ccy = Convert.ToString(((Excel.Range)sheet.Cells[3, 2]).Value2);
                double notional = Convert.ToDouble(((Excel.Range)sheet.Cells[4, 2]).Value2);
                DateTime startDate = Convert.ToDateTime(((Excel.Range)sheet.Cells[5, 2]).Value2);
                DateTime endDate = Convert.ToDateTime(((Excel.Range)sheet.Cells[6, 2]).Value2);
                string rateName = Convert.ToString(((Excel.Range)sheet.Cells[7, 2]).Value2);
                double spread = Convert.ToDouble(((Excel.Range)sheet.Cells[8, 2]).Value2);
                double fixedRate = Convert.ToDouble(((Excel.Range)sheet.Cells[9, 2]).Value2);
                return Sophis.Web.Objects.WebSwap.GetOneSwap(refe, name, true, ccy, fixedRate, rateName, spread, fixedRate, startDate, endDate);
            }
            catch (Exception ex)
            {
                sheet.Cells[4, 4] = "Exception";
                sheet.Cells[4, 5] = ex.Message;
                return null;
            }
        }

        #endregion package_valuation

        #region PortfolioValuation
           public void GetPortfolioWebValuation(Excel._Worksheet sheet)
           {
               try
               {
                   _CurentWorkSheet = sheet;
                   Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().CommunicationManagerLogged += new EventHandler(SophisSOAFunctions_CommunicationManagerLogged);
                   if (Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().IsLogged)
                    {
                        if (sheet.Names.Count > 0)
                        {
                            Name name = sheet.Names.Item("StatusVal", Type.Missing, Type.Missing);
                            Microsoft.Office.Interop.Excel.Range range = _CurentWorkSheet.get_Range(name, Type.Missing);
                            range.Value2 = "OK";
                        }
                        else
                        {
                            sheet.Cells[1, 13] = "OK";
                        }
                    }

                   ///INPUTS
                   //Read Folio Name
                   string folioName = ((Excel.Range)sheet.Cells[1, 2]).Value2.ToString();

                   //Read Header
                   List<string> columnList = new List<string>();

                   int headerColId=1;
                   int headerLineId = 5;
                   while (((Excel.Range)sheet.Cells[headerLineId, headerColId]).Value2 != null)
                   {
                       if (headerColId>2)
                            columnList.Add(((Excel.Range)sheet.Cells[headerLineId, headerColId]).Value2.ToString());
                       ++headerColId;
                   }

                   PortfolioWebValuation folioValuation = new PortfolioWebValuation();
                   ValuationRequest wRequest = folioValuation.ValuateOnePortfolio(folioName, columnList);

                   XDocument respValuation = Sophis.Web.Api.CommunicatorFactory.GetI_Communicator().Valuate(wRequest);
                   int i = 0;
                   if (
                       (respValuation.Root.Element(NS.nsValuation + "valuationSet") != null)
                       && (respValuation.Root.Element(NS.nsValuation + "valuationSet").Element(NS.nsValuation + "portfolioValuation") != null)
                       && (respValuation.Root.Element(NS.nsValuation + "valuationSet").Element(NS.nsValuation + "portfolioValuation").Element(NS.nsReporting + "reporting") != null)
                       && (respValuation.Root.Element(NS.nsValuation + "valuationSet").Element(NS.nsValuation + "portfolioValuation").Element(NS.nsReporting + "reporting").Element(NS.nsReporting + "window") != null)
                       )
                   {
                       //Header Already Set

                       //Body
                       int lineId = 6;
                       foreach (XElement xLine in respValuation.Root.Element(NS.nsValuation + "valuationSet").Element(NS.nsValuation + "portfolioValuation").Element(NS.nsReporting + "reporting").Element(NS.nsReporting + "window").Elements(NS.nsReporting + "line"))
                       {
                           int col = 1;
                           sheet.Cells[lineId, col] = xLine.Attribute(NS.nsReporting + "Id").Value;
                           ++col;
                           sheet.Cells[lineId, col] = xLine.Attribute(NS.nsReporting + "name").Value;
                           ++col;

                           for (int colId = 0; colId < columnList.Count; colId++ )
                           {
                               string colName = GetColumnTagFromName(columnList[colId]);
                               XElement xelem = xLine.Element(NS.nsReporting + colName);
                               if (xelem != null)
                               {
                                   sheet.Cells[lineId, colId+3] = xelem.Value;
                               }
                           }

                           ++lineId;
                       }
                   }

                   sheet.Cells[1, 5] = respValuation.ToString();
               }
               catch (Exception ex)
               {
                   sheet.Cells[1, 10] = ex.ToString();
               }
           }

           private string GetColumnTagFromName(string colName)
           {
               if (colName.Contains(" "))
               {
                   string result = "";
                   string[] names = colName.Split(' ');
                   result = names[0].ToLower();
                   for (int i = 1; i < names.Length; i++)
                   {
                       string firstChar = (names[i][0]).ToString();
                       firstChar = firstChar.ToUpper();
                       names[i] = firstChar + names[i].Substring(1);
                       result += names[i];
                   }
                   return result;
               }
               else
                   return colName.ToLower();
           }

           void SophisSOAFunctions_CommunicationManagerLogged(object sender, EventArgs e)
           {
               ////if (_CurentWorkSheet != null)
               ////{
               ////    Excel.Range r = _CurentWorkSheet.get_Range("StatusVal", "StatusVal");
               ////    r.Value2 = "OK";
               ////}
           }
        #endregion PortfolioValuation

        protected void CleanErrorMessage(Excel._Worksheet sheet, int startLine, int startColumn)
        {
            sheet.Cells[startLine, startColumn] = "";
            sheet.Cells[startLine, startColumn + 1] = "";
            sheet.Cells[startLine + 1, startColumn] = "";
            sheet.Cells[startLine + 1, startColumn + 1] = "";
            sheet.Cells[startLine + 2, startColumn] = "";
            sheet.Cells[startLine + 2, startColumn + 1] = "";
            sheet.Cells[startLine + 3, startColumn] = "";
            sheet.Cells[startLine + 3, startColumn + 1] = "";
        }


        protected void WriteErrorMessage(Excel._Worksheet sheet, int startLine, int startColumn, XElement xElementRejected, XNamespace ns)
        {
            sheet.Cells[startLine, startColumn] = "Message Rejected";
            sheet.Cells[startLine + 1, startColumn] = "ReasonCode";
            sheet.Cells[startLine + 1, startColumn + 1] = xElementRejected.Element(ns + "reason").Element(ns + "reasonCode").Value;
            sheet.Cells[startLine + 2, startColumn] = "Description";
            sheet.Cells[startLine + 2, startColumn + 1] = xElementRejected.Element(ns + "reason").Element(ns + "description").Value;
            sheet.Cells[startLine + 3, startColumn] = "DetailedException";
            sheet.Cells[startLine + 3, startColumn + 1] = xElementRejected.Element(NS.nsDataExchange + "details").Element(NS.nsDataExchange + "exception").Value;
        }
    }
}
