using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Data;
using System.Globalization;
using System.Diagnostics;

namespace Sophis.Windows.Converters
{
    /// <summary>
    /// Two-way converter that reverse a boolean.
    /// It converts a boolean into its opposite.
    /// The reverse conversion works the same.
    /// </summary>
    //[ValueConversion(typeof(Boolean), typeof(Boolean))]
    public class ReverseBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Boolean)
            {
                return !((Boolean)value);
            }
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is Boolean)
            {
                return !((Boolean)value);
            }
            return false;
        }
    };
}