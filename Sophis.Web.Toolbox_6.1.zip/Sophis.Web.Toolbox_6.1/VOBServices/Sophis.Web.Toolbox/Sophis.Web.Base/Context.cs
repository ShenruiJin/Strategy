﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Web.Services.Protocols;

namespace Sophis.Web.Base
{
    public class Context
    {
        public Configuration Configuration { get; private set; }

        public Context(Configuration configuration)
        {
            Configuration = configuration;
        }

        public static string GetSoapErrorCode(XmlNode errorInfo)
        {
            XmlNode code = errorInfo.SelectSingleNode("//code");

            if (code != null)
                return code.InnerText;
            else
                return "";
        }

        public static string GetSoapErrorDescription(XmlNode errorInfo)
        {
            XmlNode description = errorInfo.SelectSingleNode("//description");

            if (description != null)
                return description.InnerText;
            else
                return "";
        }

        protected virtual void GetLogParams(out string sourceType, out string source, out int depth)
        {
            sourceType = "";
            source = "";
            depth = 0;
        }

        public void Log(Severity severity, string message)
        {
            Severity severityLevel = Severity.Warning;

            if (Configuration != null && Configuration.LogSeverityLevel.HasValue)
                severityLevel = Configuration.LogSeverityLevel.Value;

            if ((int)severityLevel > (int)severity)
                return;

            StringBuilder sb = new StringBuilder();

            sb.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm::ss"));
            sb.Append('|');

            switch (severity)
            {
                case Severity.Debug:
                    sb.Append('D');
                    break;
                case Severity.Info:
                    sb.Append('I');
                    break;
                case Severity.Warning:
                    sb.Append('W');
                    break;
                case Severity.Error:
                    sb.Append('E');
                    break;
            }

            string sourceType, source;
            int depth;
            GetLogParams(out sourceType, out source, out depth);

            sb.Append('|');
            sb.Append(sourceType);
            sb.Append('|');
            sb.Append(source);
            sb.Append("|");
            sb.AppendLine(message);

            using (FileStream fs = new FileStream(Configuration.LogFile.FullName, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    sw.Write(sb.ToString());
                    sw.Flush();
                    sw.Close();
                }
                fs.Close();
            }

        }
        
        public string RetreiveLogs()
        {
            string s ="";
            using (FileStream fs = new FileStream(Configuration.LogFile.FullName, FileMode.Append, FileAccess.Read, FileShare.Read))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    s = sr.ReadToEnd();
                }
            }

            return s;
        }

        public void Log(Exception ex)
        {
            Log(ex, false);
        }

        public void Log(Exception ex, bool innerFlag)
        {
            string detail = "";
            if (ex is SoapException)
                detail = ": " + GetSoapErrorDescription(((SoapException)ex).Detail);

            StringBuilder sb = new StringBuilder();

            if (innerFlag)
                sb.Append("Inner ");

            sb.Append("Exception: ");
            sb.Append(ex.Message);
            sb.AppendLine(detail);
            sb.Append(ex.StackTrace);

            foreach (KeyValuePair<string, string> pair in ex.Data)
            {
                sb.AppendLine();
                sb.Append(pair.Key);
                sb.Append(": ");
                sb.Append(pair.Value);
            }

            Log(Severity.Error, sb.ToString());

            if (ex.InnerException != null)
                Log(ex.InnerException, true);
        }

    
    }
}
