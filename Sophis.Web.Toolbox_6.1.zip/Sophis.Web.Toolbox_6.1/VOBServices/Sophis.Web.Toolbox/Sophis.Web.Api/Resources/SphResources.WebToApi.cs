﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace Sophis.Web.Api
{
    public class SphResources
    {
        /// <summary>
        /// Retreive easly Resources by Code
        /// Look in Application.Current
        /// Look in "/Sophis.Web.Gui;component/themes/resources.xaml"
        /// and
        /// /Sophis.Web.Api;component/resources/SophisResources.xaml
        /// If Well declared in client application
        /// </summary>

        /// <summary>
        /// FindResource in all merged dictionnary Declared
        /// </summary>
        /// <param name="name">name of the key of the researched resource</param>
        /// <returns>object to cast</returns>
        public static object FindResource(string name)
        {
            if (Application.Current.Resources.Contains(name))
            {
                return Application.Current.Resources[name];
            }
            else
            {
                throw( new Exception("Unable To fin Resource "+name));
            }
        }
    }
}
