﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sophis.xaml.controls.InternalLog
{
    class InternalLogger
    {
        internal static bool Log(string className, string methodName, string verbosity, string message)
        {
            sophis.utils.CSMLog.eMVerbosity verb = sophis.utils.CSMLog.eMVerbosity.M_comm;
            if (verbosity.Contains("error"))
                verb = sophis.utils.CSMLog.eMVerbosity.M_error;
            else if (verbosity.Contains("warning"))
                verb = sophis.utils.CSMLog.eMVerbosity.M_warning;
            else if (verbosity.Contains("debug"))
                verb = sophis.utils.CSMLog.eMVerbosity.M_debug;
            else if (verbosity.Contains("verbose"))
                verb = sophis.utils.CSMLog.eMVerbosity.M_verbose;
            else if (verbosity.Contains("comm"))
                verb = sophis.utils.CSMLog.eMVerbosity.M_comm;
            else
                verb = sophis.utils.CSMLog.eMVerbosity.M_debug;


            sophis.utils.CSMLog.Write(className, methodName, verb, message);
            
            return true;
        }
    }
}
