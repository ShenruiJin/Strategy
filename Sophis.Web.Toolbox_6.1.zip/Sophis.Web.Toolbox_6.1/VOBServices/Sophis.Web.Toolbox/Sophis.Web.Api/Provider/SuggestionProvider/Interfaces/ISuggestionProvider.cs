using System.Collections.ObjectModel;

namespace Sophis.Web.Api
{
    /// <summary>
    /// The ISuggestionProvider interface should be implemented to provides a suggestion source
    /// to the AutoCompletionControl control.
    /// </summary>
    public interface ISuggestionProvider
    {
        /// <summary>
        /// Fills the provided SuggestionCollection with at most maxCount candidates for
        /// auto-completion based on the given prefix.
        /// These candidates must be chosen by matching the first characters of their Key
        /// with prefix in an InvariantCultureIgnoreCase way.
        /// The Suggestion objects must be added sorted (no sort will be effected afterwards)
        /// and their Key property must begin with prefix.
        /// </summary>
        /// <param name="suggestionList">An empty SuggestionCollection that must be filled with candidates for auto-completion</param>
        /// <param name="prefix">A string describing the prefix entered by the user, which should be used to fetch the candidates</param>
        /// <param name="maxCount">An integer representing the maximum number of candidates that should be added in suggestionList</param>
        /// <remarks>
        /// maxCount is only used to restrain the number of available candidates, especially when
        /// the user begins entering the prefix.
        /// Also note that the added candidates may not have to be the absolute maxCount first candidates.
        /// </remarks>
        void LookupPrefix(SuggestionCollection suggestionList, string prefix, int maxCount);

    }
}
