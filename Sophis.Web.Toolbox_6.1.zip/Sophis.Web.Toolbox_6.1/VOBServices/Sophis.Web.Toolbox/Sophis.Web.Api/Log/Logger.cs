﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sophis.Web.Api;
using sophis.services;



namespace Sophis.Web.Api
{
    public class Logger
    {
        protected static readonly string SOA_METHOD = "Log";

        /// <summary>
        /// Will Call the ProcessMethod with THe Log Method
        /// No Return
        /// the Log is Done on "Server/Risk" side
        /// </summary>
        /// <param name="className">Name of the Class</param>
        /// <param name="methodName">Name of the Method</param>
        /// <param name="verbosity">choose between : 'error', 'warning', 'debug', 'verbose', 'comm'</param>
        /// <param name="message">Message to log</param>
        public static void Log(string className, string methodName, string verbosity, string message)
        {
            string msgToSend = className+"; "+methodName+"; "+message;
            List<SoaMethodParameter> myParams = new List<SoaMethodParameter>() { 
                new SoaMethodParameter { name = "Message", Value = msgToSend },
                new SoaMethodParameter { name = "Verbosity", Value = verbosity }
            };

            CommunicationResultGetterInfos callerInfos = new CommunicationResultGetterInfos
            {
                Caller = null,
                CallerInfos = null
            };

            CommunicatorFactory.GetI_Communicator().ExecuteMethod(SOA_METHOD, myParams, callerInfos);
        }
    }
}
