﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;


namespace Sophis.Web.Api
{
    public class SynchronousSuggestionProvider : ISuggestionProvider, INotifyPropertyChanged
    {

        private SuggestionCollection _OriginalList = new SuggestionCollection();

        #region ISuggestionProvider Members

        public void LookupPrefix(SuggestionCollection suggestionList, string prefix, int maxCount)
        {
            int l = prefix.Length;
            int nbSugg = 0;

            suggestionList.Clear();
            foreach (Suggestion sug in OriginalItemSource)
            {
                switch (LookUpOnWhichSuggestionPart)
                {
                    case "DisplayName":
                    if (sug.DisplayName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || prefix.Length == 0)
                    {
                        sug.PrefixLength = l;
                        if (nbSugg < maxCount)
                        {
                            suggestionList.Add(sug);
                            nbSugg++;
                        }
                    }
                    break;

                    default: //Key
                    if (sug.Key.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || prefix.Length == 0)
                    {
                        sug.PrefixLength = l;
                        if (nbSugg < maxCount)
                        {
                            suggestionList.Add(sug);
                            nbSugg++;
                        }
                    }
                    break;
                }
            }
        }

        #endregion

        public SuggestionCollection OriginalItemSource
        {
            get { return _OriginalList; }
            set
            {
                _OriginalList = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("OriginalItemSource"));
            }
        }

        [DefaultValue("Key")]
        public string LookUpOnWhichSuggestionPart
        { get; set; }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

    }
}
