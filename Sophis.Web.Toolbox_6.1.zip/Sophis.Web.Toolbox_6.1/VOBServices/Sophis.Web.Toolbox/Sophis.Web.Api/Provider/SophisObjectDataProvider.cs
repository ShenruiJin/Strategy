﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Markup;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Xml.Linq;
using System.Collections.Generic;

using Sophis.Web.Api;
using sophis.services;

namespace Sophis.Web.Api
{
    public class SophisObjectDataProvider : SuggestionCollection, I_CommunicationResultGetter
    {
        #region  Data + Properties
        private string _ObjectTypeName = null;
        protected readonly string SOA_METHOD = "ObjectDataProvider";

        private I_CommunicationManager _CommManager = null;
        public I_CommunicationManager CommManager
        {
            get
            {
                return _CommManager;
            }
            set
            {
                _CommManager = value;
            }
        }
        
        /// <summary>
        /// FullName of the Type (with NameSpace).
        /// </summary>
        public string ObjectTypeName
        {
            get
            {
                return _ObjectTypeName;
            }
            set
            {
                _ObjectTypeName = value;
                this.OnPropertyChanged(new PropertyChangedEventArgs("ObjectTypeName"));
            }
        }

        private string _MethodName = null;
        /// <summary>
        /// Name of the static Method that will be called on the specifed type
        /// </summary>
        public string MethodName
        {
            get { return _MethodName; }
            set
            {
                _MethodName = value;
                this.OnPropertyChanged(new PropertyChangedEventArgs("MethodName"));

            }
        }

        private string _AssemblyName;
        /// <summary>
        /// Name of the Assembly the Class is in (without ".dll" nor ".exe" extension)
        /// </summary>
        public string AssemblyName
        {
            get { return _AssemblyName; }
            set
            {
                _AssemblyName = value;
                this.OnPropertyChanged(new PropertyChangedEventArgs("AssemblyName"));
            }
        }
        #endregion Data + Properties

        #region Init

        /// <summary>
        /// Return Trus If the object Is Well initialized, and ready to bu used.
        /// </summary>
        /// <returns>true if Well Initailied</returns>
        private bool IsInitialized()
        {
            if (MethodName == null)
                return false;
            if (ObjectTypeName == null)
                return false;
            if (AssemblyName == null)
                return false;
            return true;
        }

        protected override void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);

            if (e.PropertyName == "ObjectTypeName" || e.PropertyName == "MethodName" || e.PropertyName == "AssemblyName")
            {
                if (IsInitialized())
                {
                    List<SoaMethodParameter> myParams = new List<SoaMethodParameter>();
                    myParams.Add(new SoaMethodParameter { name = "TypeName", Value = ObjectTypeName });
                    myParams.Add(new SoaMethodParameter { name = "MethodName", Value = MethodName });
                    myParams.Add(new SoaMethodParameter { name = "AssemblyName", Value = AssemblyName });
                    CommunicationResultGetterInfos callerInfos = new CommunicationResultGetterInfos
                    {
                        Caller = this,
                        CallerInfos = SOA_METHOD
                    };
                    if (_CommManager == null)
                        CommunicatorFactory.GetI_Communicator().ExecuteMethod(SOA_METHOD, myParams, callerInfos);
                    else
                        _CommManager.ExecuteMethod(SOA_METHOD, myParams, callerInfos);
                }
            }
        }
        #endregion Constrturtor + Init

        #region I_CommunicatorResultGetter Members
        public void MethodHasCompleted(string methodName, XDocument result, object info)
        {
            if (methodName == SOA_METHOD)
            {
                if ( result != null && 
                    (result.FirstNode as XElement) != null &&
                    ((result.FirstNode as XElement).FirstNode as XElement) != null &&
                    (((result.FirstNode as XElement).FirstNode as XElement).Descendants()) != null) 
                {
                    foreach (XElement elem in ((result.FirstNode as XElement).FirstNode as XElement).Descendants())
                    {
                        //this.Add(new KeyString(int.Parse(elem.Attribute("key").Value), elem.Value));
                        this.Add(new Suggestion(elem.Attribute("key").Value, elem.Value));
                    }
                }
            }
        }

        public void MethodFailed(string methodName, XDocument result, object info)
        {
            this.Add(new Suggestion("Error", methodName+" failed"));
        }
        #endregion
    }
}
