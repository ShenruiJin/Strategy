﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using sophis.services;

namespace Sophis.Web.Api
{
    public class SophisObjectProxy
    {
        public SophisContext Context { get; private set; }

        public SophisObjectProxy(SophisContext context)
        {
            Context = context;
        }
        static private NumberFormatInfo nfi = null; 

        public static double ParseDouble(string value)
        {
            if (nfi == null)
            {
                nfi = new NumberFormatInfo();
                nfi.NumberDecimalSeparator = ".";
            }

            return Math.Round(Double.Parse(value, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign | NumberStyles.AllowExponent, nfi), 3);
        }

        public static int ParseInt(string value)
        {
            return Int32.Parse(value);
        }

        public static DateTime ParseDateTime(string value)
        {
            return DateTime.Parse(value, new SophisFormatProvider());
        }

        public static string ExtractRejectionMessage(MessageRejected rejected)
        {
            StringBuilder sb = new StringBuilder();
            if (rejected != null)
            {
                string sep = " Reason: ";
                foreach (Reason reason in rejected.reason)
                {
                    sb.Append(sep);
                    sb.Append(reason.description);
                    sep = ", ";
                }
            }
            return sb.ToString();
        }

    }

    public class SophisFormatProvider : IFormatProvider
    {

        #region IFormatProvider Members

        public object GetFormat(Type formatType)
        {
            if (formatType == typeof(DateTimeFormatInfo))
                return "yyyy-MM-dd";
            throw new NotImplementedException();
        }

        #endregion
    }

}
