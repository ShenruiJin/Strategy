﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Documents;
using System.Xml.Linq;
using System.Collections.ObjectModel;
using System.ComponentModel;

using Sophis.Web.Api;
using sophis.services;


namespace Sophis.Web.Api
{
    
    /// <summary>
    /// Base Class which Will deal with Risk:IntegrationService (SoaMethd Designer) through SQL source to provide List of desired Item
    /// You should inherit fro this class and ovveride at least Init Method
    /// Override Init To Set the table and column name needed.
    /// Warning ! With a complex request also override "FillList" to do exactly what is needed.
    /// </summary>
    public class SQLProvider : INotifyPropertyChanged, I_CommunicationResultGetter
    {

        public enum e_KeyField
        {
            eDefault,
            eKey,
            eName,
            eReference,
            eId
        }

        #region Data
        protected ObservableCollection<GenericItem> _FullItemlist = new ObservableCollection<GenericItem>();

        List<long> _IdsFilter = null;
        protected ObservableCollection<GenericItem> _PartialItemlist = new ObservableCollection<GenericItem>();

        protected string _TableName;
        protected string _IdField;
        protected string _NameField;
        protected string _RefField;
        protected string _OrderBy = String.Empty;

        public e_KeyField KeyField { get; set; }

        private bool _IniFullList = true;
        public bool InitFullList { get { return _IniFullList; } }

        protected static readonly XNamespace SoaMdNs = "http://www.sophis.net/DotNetReporting";
        
        
        /// <summary>
        /// Must contain the 'WHERE' clause : eg : ' where options = 2 '
        /// </summary>
        protected string _Condition = String.Empty;
        #endregion Data

        #region Constrtuctors
        /// <summary>
        /// Init the Full List
        /// </summary>
        public SQLProvider()
        {
            KeyField = e_KeyField.eDefault;
            Init();
            GetFullList();
        }

        /// <summary>
        /// Allow to create the provider, without loading the full list
        /// </summary>
        /// <param name="initFullList">false : the fulll list is not loaded</param>
        public SQLProvider(bool initFullList)
        {
            Init();
            _IniFullList = initFullList;
            if (_IniFullList)
                GetFullList();
        }

        /// <summary>
        /// Allow to create a provider Laoding directly a partial list
        /// </summary>
        /// <param name="initFullList">if true : load Fukll list, if false, look at next param( ids)</param>
        /// <param name="ids">id null, not load partial list, if not null, will load partial list by filtering Id items with this list.</param>
        public SQLProvider(bool initFullList, List<long> ids)
        {
            Init();
            _IniFullList = initFullList;
            if (_IniFullList)
                GetFullList();
            if (ids != null && ids.Count>0)
            {
                _IdsFilter = ids;
                GetPartialList(_IdsFilter);
            }
        }

        /// <summary>
        /// Re load the list with Param
        /// </summary>
        /// <param name="initFullList">if true : load the Full list, and ignore the second param, if false, use'ids'.It will fill the FullItemList</param>
        /// <param name="ids">list of Ids that will filter list and fill the PartialItemlist</param>
        public void LoadList(bool initFullList, List<long> ids)
        {
            try
            {
                _IniFullList = initFullList;
                if (_IniFullList)
                    GetFullList();
                if (ids != null && ids.Count > 0)
                {
                    _IdsFilter = ids;
                    GetPartialList(_IdsFilter);
                }
            }
            catch( Exception e)
            {
                Logger.Log(this.ToString(), "LoadList", "error", "ERROR =" + e.ToString());
                System.Diagnostics.Debugger.Break();
            }
        }
        protected virtual void Init()
        {
        }
        #endregion Init


        #region Public Properties
        /// <summary>
        /// Fill FullItemlist if it has not already been done.
        /// </summary>
        /// <returns></returns>
        //protected abstract List<GenericItem> GetList();
        /// <summary>
        /// Get the FullIem List
        /// </summary>
        public ObservableCollection<GenericItem> FullItemlist
        {
            get
            {
                if (_FullItemlist.Count == 0)
                    GetFullList();

                return _FullItemlist;
            }
        }

        public ObservableCollection<GenericItem> PartialItemlist
        {
            get
            {
                if (_PartialItemlist.Count == 0 && _IdsFilter != null && _IdsFilter.Count > 0)
                    GetPartialList(_IdsFilter);

                return _PartialItemlist;
            }
        }
        #endregion  Public Properties

        #region Protected Methods
        protected virtual  void GetFullList()
        {
            string query = "select " + _IdField + ", " + _NameField + ", " + _RefField + " from " + _TableName;
            if (_Condition != String.Empty)
                query += " " + _Condition;
            if (_OrderBy != String.Empty)
                query += " order by " + _OrderBy;
            Logger.Log(this.ToString(), "GetFullList", "verbose", "Query =" + query);
            ExcuteQueryAndFillList(query, "FullItemlist");
        }

        protected virtual void GetPartialList(List<long> ids)
        {
            StringBuilder inStr = new StringBuilder("select " + _IdField + ", " + _NameField + ", " + _RefField + " from " + _TableName);
            if (_Condition != String.Empty)
            {
                inStr.Append(" " + _Condition);
                inStr.Append(" and " + _IdField + " in  (");
            }
            else
                inStr.Append(" where " + _IdField + " in  (");

            foreach (long id in ids)
            {
                inStr.Append("'");
                inStr.Append(id);
                inStr.Append("', ");
            }
            inStr.Remove(inStr.Length - 2, 2);
            inStr.Append(")");
            
            if (_OrderBy != String.Empty)
                 inStr.Append(" order by " + _OrderBy);

            Logger.Log(this.ToString(), "PartialItemlist", "verbose", "Query =" + inStr.ToString());
            ExcuteQueryAndFillList(inStr.ToString(), "PartialItemlist");
            
        }

        protected void ExcuteQueryAndFillList(string query, string target)
        {
            // XDocument result = ExecuteQuery(query);
            ExecuteQuery(query, target);
            //Thing to dealWith Asynchrone
        }

        protected virtual ObservableCollection<GenericItem> FillList(XDocument counterpartyxDoc)
        {
            
            ObservableCollection<GenericItem> itemlist = new ObservableCollection<GenericItem>();
            List<GenericItem> list = (from table in counterpartyxDoc.Root.Descendants(SQLProvider.SoaMdNs + "TableResult")
                                      select new GenericItem 
                                      {
                                          Key = (table.Element(SQLProvider.SoaMdNs + _IdField.ToUpper()) != null) ? table.Element(SQLProvider.SoaMdNs + _IdField.ToUpper()).Value : "0",
                                          DisplayName = (table.Element(SQLProvider.SoaMdNs + _NameField.ToUpper()) != null) ? table.Element(SQLProvider.SoaMdNs + _NameField.ToUpper()).Value : "",
                                          Reference = (table.Element(SQLProvider.SoaMdNs + _RefField.ToUpper()) != null) ? table.Element(SQLProvider.SoaMdNs + _RefField.ToUpper()).Value : "" //,
                                          //Key = ((this.KeyField == e_KeyField.eName) ? ((table.Element(GenericSQLProvider.SoaMdNs + _NameField.ToUpper()) != null) ? table.Element(GenericSQLProvider.SoaMdNs + _NameField.ToUpper()).Value : "") : ((table.Element(GenericSQLProvider.SoaMdNs + _IdField.ToUpper()) != null) ? table.Element(GenericSQLProvider.SoaMdNs + _IdField.ToUpper()).Value : "0"))
                                      } 
             ).ToList();
            if (list != null)
                list.ForEach(x => itemlist.Add(x));
            return itemlist;
            
        }
        #endregion Protected Methods

        #region Privates Methods && asynchronous
        /// <summary>
        /// Asynchrounous Answer
        /// </summary>
        /// <param name="query"></param>
        private void ExecuteQuery(string query,  string target)
        {
            List<SoaMethodParameter> myParams = new List<SoaMethodParameter>();
            myParams.Add(new SoaMethodParameter { name = "query", Value = query });
            CommunicationResultGetterInfos callerInfos = new CommunicationResultGetterInfos
            {
                Caller = this,
                CallerInfos = target 
            };
            CommunicatorFactory.GetI_Communicator().ExecuteMethod("ExecuteSQlQuery", myParams, callerInfos);
            //XDocument xdoc = DataBase.DBCommunicator.Instance.ExecuteSQlQuery(query);
            //return xdoc; The retrun Is Void because it is asynchrouneous
        }
        #region I_CommuniatorResultGetter Members

        public void MethodHasCompleted(string methodName, XDocument result, object info)
        {
            if (methodName == "ExecuteSQlQuery")
            {
                CommunicationResultGetterInfos callerInfos = info as CommunicationResultGetterInfos;
                if (callerInfos != null && callerInfos.CallerInfos != null)
                {
                    string target = callerInfos.CallerInfos as string;
                    if (target == "PartialItemlist")
                    {
                        _PartialItemlist = FillList(result);
                        if (PropertyChanged != null)
                            PropertyChanged(this, new PropertyChangedEventArgs("PartialItemlist"));
                    }
                    else
                    {
                        _FullItemlist = FillList(result);
                        if (PropertyChanged != null)
                            PropertyChanged(this, new PropertyChangedEventArgs("FullItemlist"));
                    }
                }
                else
                {
                    _FullItemlist = FillList(result);
                    if (PropertyChanged != null)
                        PropertyChanged(this, new PropertyChangedEventArgs("FullItemlist"));
                }

                ////If Gui Controls Are Linked on the Observalble Collection
                ////We raise the appropriate Event for the Gui To refresh it self.
                //if (PropertyChanged != null)
                //{
                //    PropertyChanged(this, new PropertyChangedEventArgs("FullItemlist"));
                //    PropertyChanged(this, new PropertyChangedEventArgs("PartialItemlist"));
                //}
            }
        }

        public void MethodFailed(string methodName, XDocument result, object info)
        {
        }

        #endregion
        #endregion Privates Methods && asynchronous


        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion
    }



 
}
