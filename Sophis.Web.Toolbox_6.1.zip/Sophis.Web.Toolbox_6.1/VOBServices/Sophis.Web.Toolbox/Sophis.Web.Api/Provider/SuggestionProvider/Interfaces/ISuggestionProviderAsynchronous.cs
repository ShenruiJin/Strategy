﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Sophis.Web.Api
{
    /// <summary>
    /// This Interface is interrsting to Implement fo a Provider which has to Rebuild
    /// Suggestion list on each LokkupPrefix
    /// Passing trough SOA (AsynchroneousCall)#
    /// 
    /// Throwing the event that way
    /// if (UpdateSugestionList!=null)
    ///     UpdateSugestionList(null,null);
    ///     
    /// Allows the client of the provider to know the Suggestion List has been updated
    /// </summary>
    public interface ISuggestionProviderAsynchronous : ISuggestionProvider
    {
        /// <summary>
        /// In Silverlight, Once the Suggestion List Is Updated
        /// </summary>

        event EventHandler<SugestionListEventArgs> UpdateSugestionList;
    }

    public class SugestionListEventArgs : EventArgs
    {
        public SuggestionCollection Suggestions { get; set; }
    }
}
