﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Sophis.Web.Api;

namespace Sophis.Web.TestAppli.Net
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        Sophis.Web.Base.Context _Context;

        public Window1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            I_CommunicationManager mngr = CommunicatorFactory.GetI_Communicator();

            _Context = new Sophis.Web.Base.Context(CommunicatorFactory.GetI_Communicator().Configuration);

            _Context.Log(Sophis.Web.Base.Severity.Error, "Test1");

            Logger.Log("Sophis.Web.TestAppli.Net.Window1", "button1_Click", "error", "TEST, ceci est un TEST");

        }
    }
}
