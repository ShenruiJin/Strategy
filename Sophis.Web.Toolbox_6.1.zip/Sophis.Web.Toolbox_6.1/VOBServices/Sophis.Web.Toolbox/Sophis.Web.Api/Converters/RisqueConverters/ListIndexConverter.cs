using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Data;
using System.Globalization;

namespace Sophis.Windows.Converters
{
    //[ValueConversion(typeof(Int32), typeof(Int32))]
    public class ListIndexConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (Int32)value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Int32 itemNum = 0;
            if (value != null)
                itemNum = (Int32)value;
            return itemNum;
        }
    }
}
