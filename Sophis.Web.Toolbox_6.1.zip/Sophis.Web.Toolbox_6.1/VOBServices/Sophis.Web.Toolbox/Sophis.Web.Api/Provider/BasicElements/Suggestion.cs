using System;

namespace Sophis.Web.Api
{
    /// <summary>
    /// The Suggestion object is a container storing data, a key and a name string,
    /// to identify a candidate for the AutoCompletionControl control.
    /// Suggestion also provides a PrefixLength property where the length of the prefix
    /// used to retrieve the candidate should be stored, as an example to use it in
    /// a PrefixedTextBlock.
    /// </summary>
    public class Suggestion
    {
        #region Private Members

        private string _Key = string.Empty;
        private string _DisplayName = string.Empty;
        private int _PrefixLength = 0;

        #endregion

        #region Constructors

        /// <summary>
        /// Trivial constructor.
        /// Key and Name are empty and PrefixLength equals zero.
        /// </summary>
        public Suggestion()
        {
            _Key = string.Empty;
            _DisplayName = string.Empty;
        }

        /// <summary>
        /// Constructor that initializes both Key and Name to the same parameter key.
        /// PrefixLength is initialized at zero.
        /// </summary>
        /// <param name="key">A string to use as both Key and Name</param>
        public Suggestion(string key)
        {
            _Key = key;
            _DisplayName = key;
        }

        /// <summary>
        /// Constructor that initializes both Key and Name to the same parameter key and
        /// PrefixLength to the parameter prefixLength.
        /// </summary>
        /// <param name="key">A string to use as both Key and Name</param>
        /// <param name="prefixLength">An integer specifying the length of the prefix</param>
        public Suggestion(string key, int prefixLength)
        {
            _Key = key;
            _DisplayName = key;
            _PrefixLength = prefixLength;
        }

        /// <summary>
        /// Constructor that initializes Key to the parameter key and Name to the parameter name.
        /// PrefixLength is initialized at zero.
        /// </summary>
        /// <param name="key">A string to use as Key</param>
        /// <param name="name">A string to use as Name</param>
        public Suggestion(string key, string name)
        {
            _Key = key;
            _DisplayName = name;
        }

        /// <summary>
        /// Constructor that initialized Key to the parameter key, Name to the parameter Name
        /// and PrefixLength to the parameter prefixLength.
        /// </summary>
        /// <param name="key">A string to use as Key</param>
        /// <param name="name">A string to use as Name</param>
        /// <param name="prefixLength">An integer to use as PrefixLength</param>
        public Suggestion(string key, string name, int prefixLength)
        {
            _Key = key;
            _DisplayName = name;
            _PrefixLength = prefixLength;
        }

        /// <summary>
        /// Copy constructor which uses the Key, Name and PrefixLength defined in
        /// the parameter toCopy.
        /// </summary>
        /// <param name="toCopy">A Suggestion object, which must not be null, whose members are used to initialize the created object.</param>
        /// <exception cref="System.ArgumentNullException">Thrown when the parameter toCopy is a null reference</exception>
        public Suggestion(Suggestion toCopy)
        {
            if (null == toCopy)
                throw new ArgumentNullException();
            _Key = toCopy.Key;
            _DisplayName = toCopy.DisplayName;
            _PrefixLength = toCopy.PrefixLength;
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Returns a string representation of the Suggestion object.
        /// "Key (Name)"
        /// </summary>
        /// <returns>A string that represents the Suggestion object.</returns>
        public override string ToString()
        {
            return _Key + " (" + _DisplayName + ")";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the string that uniquely identifies the suggested candidate.
        /// </summary>
        public string Key
        {
            get { return _Key; }
            set { _Key = value; }
        }

        /// <summary>
        /// Gets or sets the string that corresponds to the name of the suggested candidate.
        /// </summary>
        public string DisplayName
        {
            get { return _DisplayName; }
            set { _DisplayName = value; }
        }

        /// <summary>
        /// Gets or sets the length of the prefix used to retrieve the suggested candidate.
        /// </summary>
        public int PrefixLength
        {
            get { return _PrefixLength; }
            set { _PrefixLength = value; }
        }

        #endregion
    }
}