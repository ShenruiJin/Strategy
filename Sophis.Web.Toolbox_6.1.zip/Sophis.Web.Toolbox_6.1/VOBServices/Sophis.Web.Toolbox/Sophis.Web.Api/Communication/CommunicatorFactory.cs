﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sophis.Web.Api
{
    //http://msdn.microsoft.com/en-us/library/wewwczdw.aspx
    public sealed  class CommunicatorFactory
    {
        static volatile  I_CommunicationManager _CurrentCommunicator;
        private static object syncRoot = new Object();


        static public I_CommunicationManager GetI_Communicator()
        {
            if (_CurrentCommunicator == null)
            {
                lock (syncRoot)
                {
                    if (_CurrentCommunicator == null)
                    {
                        _CurrentCommunicator = new SophisCommunicationManager();
                    }
                }
            }
            return _CurrentCommunicator;
            
        }
    }


}
