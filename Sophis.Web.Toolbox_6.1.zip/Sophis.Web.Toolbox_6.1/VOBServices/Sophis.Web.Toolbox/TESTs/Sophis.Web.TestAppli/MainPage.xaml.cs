﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

#if WEB_TO_API
using Sophis.Windows;
using Sophis.Windows.Data;
#endif

namespace Sophis.Web.Api.TestingAppli.SL
{
    public partial class MainPage : UserControl
    {
        Sophis.Web.Base.Context _Context;
        public MainPage()
        {
#if WEB_TO_API
            InitGUI();
#else
            CommunicatorFactory.GetI_Communicator().CommunicationManagerLogged += new EventHandler(MainPage_CommunicationManagerLogged);
#endif
        }

        void MainPage_CommunicationManagerLogged(object sender, EventArgs e)
        {
            InitGUI();
        }

        private void InitGUI()
        {
            _Context = new Sophis.Web.Base.Context(CommunicatorFactory.GetI_Communicator().Configuration);

            Logger.Log("Toolbox-TestPage", "InitGui", "debug", "BEGIN");

            InitializeComponent();

            //SynchronousSuggestionProvider ssg = new SynchronousSuggestionProvider();
            //SuggestionCollection coll = SphResources.FindResource("EntityODP") as SuggestionCollection;
            //if (coll != null)
            //    ssg.OriginalItemSource = coll;
            //_SACC_1.SuggestionProvider = ssg;
            //Logger.Log("Toolbox-TestPage","InitGui","debug","END");
        }


        #region Handle
        private void _B_Log_Click(object sender, RoutedEventArgs e)
        {
            Logger.Log("Toolbox-TestPage", "_B_Log_Click", "error", _TBX_Log.Text);

            //Sophis.Web.Gui.GenericAutoCompleteBox
        }
        #endregion Handle

        private void _B_Log2_Click(object sender, RoutedEventArgs e)
        {

            _Context.Log(Sophis.Web.Base.Severity.Error, _TBX_Log2.Text);
        }

        private void _B_Log3_Click(object sender, RoutedEventArgs e)
        {
            string logs = _Context.RetreiveLogs();
            _L_Logs.Text = logs;
        }
    }
}
