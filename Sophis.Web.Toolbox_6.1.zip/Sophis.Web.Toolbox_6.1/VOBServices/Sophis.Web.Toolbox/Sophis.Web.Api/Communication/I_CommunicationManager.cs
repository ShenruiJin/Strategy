﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.ComponentModel;
using sophis.services;


namespace Sophis.Web.Api
{
    public interface I_CommunicationManager
    {
        /// <summary>
        /// Process the Method in an asynchrouneous Way (Or "Asynchrouneous Like" but synchone if we are inside Risk)
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="paramList"></param>
        /// <param name="callerInfos"></param>
        void ExecuteMethod(string methodName, List<SoaMethodParameter> paramList, CommunicationResultGetterInfos callerInfos);

        XDocument ExecuteMethod(string methodName, List<SoaMethodParameter> paramList);

        XDocument Import(ImportMessage import);

        XDocument Import(string importString);

        XDocument Export(sophis.services.ExportMessage export);

        XDocument Valuate(sophis.services.ValuationRequest valuation);

        string ExtractRejectionMessage(XElement xElementRejected);

        bool IsLogged {get;}

        DataExchangeService ServiceDataExchange {get;}
        SoaMethodDesignerService ServiceSoaDesigner {get;}
        ValuationService ServiceValuation {get;}

        event EventHandler CommunicationManagerLogged;
        event EventHandler CommunicationManagerUnLogged;

        Sophis.Web.Base.Configuration Configuration { get; }
    }


    public interface I_CommunicationResultGetter
    {
        /// <summary>
        /// Warn the Communicator Caller that the result is available
        /// </summary>
        /// <param name="methodName">methodName</param>
        /// <param name="result">Result</param>
        /// <param name="info">CommunicationResultGetterInfos</param>
        void MethodHasCompleted(string methodName, XDocument result, object info);

        /// <summary>
        /// War the communicator Caller that the Methds failed to be executed
        /// </summary>
        /// <param name="methodName">methodName</param>
        /// <param name="result">SophisCommunicationManager.nsDataExchange+"elementRejected" node</param>
        /// <param name="info">CommunicationResultGetterInfos</param>
        void MethodFailed(string methodName, XDocument result, object info);
    }

    public class CommunicationResultGetterInfos
    {
        public I_CommunicationResultGetter Caller { get; set; }
        public object CallerInfos{get;set;}
        public string MethodName { get; set; }
    }
}
